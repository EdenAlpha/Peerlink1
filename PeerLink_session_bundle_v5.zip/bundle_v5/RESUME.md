# RESUME — PeerLink session restore guide (v5)

This bundle is self-contained for all code, analysis databases, decoded
knowledge and the working oracle. Two large artifacts are intentionally
NOT included and must be re-fetched (~5 minutes, scripted):

1. `libUE4.so` (160 MB, Konami proprietary — re-download from APKCombo)
2. the full replay corpus (462 MB decompressed — only the 21 tutorial
   replay pairs + constants are included here; the rest re-extracts from
   the asset pack)

## 1. Environment

```bash
python3 -m venv /home/z/.venv
/home/z/.venv/bin/pip3 install unicorn==2.1.4 capstone==5.0.9 pyelftools==0.33 numpy scipy
```

Any Linux x86_64 box with ~2 GB RAM works. Disk: ~1 GB free minimum.

## 2. Re-fetch the exact binary

```bash
# The signed R2 URL expires after ~4h. Get a fresh one:
#   open https://apkcombo.com/efootball-2024/jp.konami.pesam/old-versions/
#   -> click 11.0.1 -> the download page contains href="/r2?u=..."
#   -> save as scripts/r2_url.txt (full https://apkcombo.com/r2?u=...)
/home/z/.venv/bin/python scripts/apks_surgical_download.py   # manifest
/home/z/.venv/bin/python scripts/fetch_libue4.py             # arm64 split + libUE4.so
```

Source: APKCombo, eFootball (KONAMI), version 11.0.1, versionCode 311000101,
arm64-v8a split. Verify:

```bash
sha256sum apk_lab/libUE4.so
# MUST be:
# 2ac4ff17ac8ad713d9531c2601e38a3c8335e02ea882ba2dc4445c191c1298cd
```

Every address in FINDINGS.md is only valid for this exact build.

## 3. Re-fetch the full replay corpus (optional)

The bundle ships all 21 tutorial replay pairs + constants (incl.
`constant_match.bin` → the ball.o source). For the rest:

```bash
/home/z/.venv/bin/python scripts/inner_apk_remote.py   # pulls dt270_mobile_all.cpk
/home/z/.venv/bin/python scripts/cpk_extract.py        # extracts all 81 files
```

ball.o is pre-extracted at `apk_lab/ball.o` (1040 bytes; verify
`ball.o[0x30] == 0x00`, floats 7.5 at 0x2c/0x140, 0.8 at 0x3f0).

## 4. Directory layout (what the scripts expect)

```
/home/z/my-project/
  scripts/          # all harnesses (this bundle, verbatim)
  apk_lab/
    libUE4.so       # re-fetched (step 2)
    ball.o
    analysis/       # static-analysis DBs (plt_map.json, bl_map.npz, *.asm, *.json) - included
    cpk/dt270_out/  # oracle corpus - 21 tutorial pairs included
  worklog.md
```

## 5. Verify the restore (expected outputs)

```bash
cd /home/z/my-project
/home/z/.venv/bin/python scripts/ball_object_run.py
# -> F0/F1/FC pass, F2 30/30 ticks 0 byte diffs, F3 max_byte_diff 0,
#    FB peaks [2.0458, 1.4216, 0.9589, 0.6415, 0.4748, 0.3457]
#    restitution 0.6949, ALL PASS: True   (runtime: ~15 s)

/home/z/.venv/bin/python scripts/rep_flight_fit.py
# -> gravity_idx0..6: -9.8067
#    fit: v0=[24.76, 5.2, -4.7] rot=[0,0,0] airRegist=0.3990
#    resid rms: 0.0241 m   oos max err: 0.0774 m

/home/z/.venv/bin/python scripts/match_core_run.py
# -> M0 PASS (manager vtable 0x978d388), M1 PASS (real game path runs,
#    6 kernel calls), M4/M4b driven-driver decode, M3 13-byte diffs

/home/z/.venv/bin/python scripts/m5d_flight_validate.py
# -> real-path flight frames 49..54 errors 2.4..10 cm; recorder idx2
#    record per tick = the .rep record stream

/home/z/.venv/bin/python scripts/matchmain_run.py          # NEW v5 (M6)
# -> [M6] data plugs: hub/team regions valid, sources NULL
# -> [SM call] {'error': None}
# -> M6a events: sm_enter, playing_enter, input_collect_enter,
#    ball_update_enter, team_orch_enter; kernel_calls 6
# -> M6c dt=0.03703703731298447 pass; M6b faults (only benign pthread
#    import noise); M6e blocks ~1.9k (with tracer overhead)

/home/z/.venv/bin/python scripts/matchmain_exec.py          # NEW v5 (M6 coverage)
# -> blocks ~38k, functions 495, player-range 107, ball_158_diffs 0

/home/z/.venv/bin/python scripts/inputbank_run.py          # NEW v5 (M7a)
# -> ctor error None, 21068 blocks, 0 faults, 18161 nonzero bytes

/home/z/.venv/bin/python scripts/m8_kick_installer.py       # NEW v5 (M8)
# -> installer error None; +0x30 28 bytes changed; substate 7 (KICKED);
#    [module+0x2D8]=3; velocity zeroed by design
```

If all reproduce, the environment is identical to the session that
produced this bundle.

## 6. Harness index (v5 additions bold)

| Script | Purpose |
|---|---|
| `uc_loader2.py` | enhanced Unicorn loader (relocs, GOT hijack, stubs, fabricators, watchers) |
| `ball_object_run.py` | **M2**: real ball module + bit-exact suite (F0/F1/F2/F3/FB/FC) |
| `rep_flight_fit.py` | **M3**: replay-oracle flight fit (record-stream semantics) |
| `match_core_run.py` | **M4**: module-manager tick harness (manager ctor, real game path 0x6a059b0, driven-driver decode) |
| `m5d_flight_validate.py` / `m5g_flight_spin.py` | **M5**: real-path flight validation via 0x6e92ce8 + spin install |
| **`matchmain_run.py`** | **M6: the MatchMain state machine harness** — full playing frame through 0x69917d8 → 0x69919e0 |
| **`matchmain_exec.py`** | **M6: execution coverage** (495 functions, write map, mm_exec_funcs.npy) |
| **`inputbank_run.py`** | **M7a: real input bank ctor 0x6a06b60 headless** |
| **`m8_kick_installer.py`** | **M8: real kick installer 0x6e93aec** (KICKED substate, velocity-zeroed semantics) |
| **`trep_deep.py`** | **M7: .trep structure decode** (24×0x3A input records, analog, camera, trajectory) |
| **`scan.py`** | **correct vaddr→offset code scanner (adrp page refs, BL callers)** — replaces the old misaligned scans |
| **`fetch_libue4.py`** | **arm64 split download + libUE4.so extraction** |
| `bscan.py` | B tail-call edge scan → `fgraph2.npz` (BL+B function graph) |
| `match_climb.py` / `vt_climb.py` / `table_map.py` / `spine_map.py` / `wall_cross.py` | M4 climb toolchain (ancestry intersection, vtable dumps, module manifest, closure funnel) |
| `trep_probe.py` | .trep input-stream structure probe (superseded by trep_deep.py) |
| `ball_poc.py` | M1 kernel PoC (E1 gravity, reference values) |
| `uc_stub_test.py` | loader selftest (timestep provider = 27.0) |
| `disasm.py` | capstone function dumper w/ PLT resolution (always was offset-correct) |
| `apks_surgical_download.py` / `inner_apk_remote.py` | binary + data recovery |
| `cpk_extract.py` | CPK archive extractor |
| `replay_parse.py` | `.rep`/`.trep` oracle parser |
| `ladder_probe.py`, `drag_guard_probe2.py`, `observer_dump.py` | session probes (kept for reference) |
| `elf_recon.py`, `symbol_mine.py`, `vtable_scan.py`, `xref_scan.py`, `kernel_anatomy.py`, `closure.py`, `convergence.py`, `climb.py`, `pes_source_map.py`, `g7_validate.py`, `verify.py`, `decode_packed.py` | Session-A static analysis toolchain |
| **`mm_decode.py`** / **`mm_layout.py`** | MatchMain SM jump-table decode / layout map |

## 7. Where the work stands (v5)

Read `FINDINGS.md` (complete decoded-knowledge index, now with §11–§15)
and `worklog.md` (chronological session log). Short version:

- M1 PASS, M2 PASS (bit-exact, 0/296 byte diffs over 30-tick trajectories)
- M3 flight fit CLOSED at cm-level (airRegist 0.399, zero spin)
- M4: match update spine found; module-manager layer executes headlessly
- M5: lockstep bridge decoded — real per-frame tick 0x6e92ce8, params
  offset root cause, input bus located, real-path flight at cm-level
- **M6 (this bundle): THE MATCHMAIN STATE MACHINE RUNS HEADLESSLY** —
  state 1 (PLAYING) → 0x69919e0 → input collect → ball module manager
  (6 kernel calls) → dt 1/27 → team orchestrator; ZERO faults; 495
  functions covered; data-only plugs discovered (§13.3)
- **M7a (this bundle): the real input bank constructs headlessly** (21k
  blocks, 1200-frame ring) and the .trep input stream is decoded to field
  level (24×0x3A records + analog cluster + camera + trajectory)
- **M8 (this bundle): the real kick installer demonstrated** — substate 7
  KICKED installed; velocity zeroed BY DESIGN → the action processor
  (paramsB) is the pinpointed next climb
- Remaining for 1200/1200 (FINDINGS §15): player module construction
  (manifest 0x98d0500, construction driver 0x6a02000), the action
  processor → kick velocity/spin/ladder, input-bank feed of .trep samples,
  then the full differential replay test.

The original repo (Session-A handoff + QWESYS decoders) lives at
https://github.com/EdenAlpha/Peerlink1 — it is the historical recovery
source for this project.
