6ea20fc: sub sp, sp, #0x90
6ea2100: str d8, [sp, #0x20]
6ea2104: stp x29, x30, [sp, #0x30]
6ea2108: stp x28, x27, [sp, #0x40]
6ea210c: stp x26, x25, [sp, #0x50]
6ea2110: stp x24, x23, [sp, #0x60]
6ea2114: stp x22, x21, [sp, #0x70]
6ea2118: stp x20, x19, [sp, #0x80]
6ea211c: add x29, sp, #0x30
6ea2120: mrs x26, tpidr_el0
6ea2124: mov x24, x2
6ea2128: mov x19, x0
6ea212c: ldr x9, [x26, #0x28]
6ea2130: mov x0, x8
6ea2134: mov w2, #0x128
6ea2138: mov w21, w5
6ea213c: mov w22, w4
6ea2140: mov w23, w3
6ea2144: fmov s8, s0
6ea2148: mov x20, x8
6ea214c: str x9, [sp, #0x18]
6ea2150: bl #0x8b35300
6ea2154: mov x0, x19
6ea2158: bl #0x6ea4ba0
6ea215c: ldrb w8, [x0]
6ea2160: ands w27, w8, #0xff
6ea2164: b.eq #0x6ea2288
6ea2168: mov w25, wzr
6ea216c: add x1, sp, #0x14
6ea2170: mov x0, x19
6ea2174: strb w25, [sp, #0x14]
6ea2178: bl #0x6ea4ba8
6ea217c: ldr x8, [x0]
6ea2180: mov x1, x20
6ea2184: ldr x8, [x8, #0x10]
6ea2188: blr x8
6ea218c: add w25, w25, #1
6ea2190: cmp w27, w25
6ea2194: b.ne #0x6ea216c
6ea2198: cmp w22, #0
6ea219c: b.le #0x6ea22d0
6ea21a0: fmov s0, #1.00000000
6ea21a4: fdiv s8, s0, s8
6ea21a8: cbz w27, #0x6ea2298
6ea21ac: mov w25, wzr
6ea21b0: mov w28, wzr
6ea21b4: add x1, sp, #0x10
6ea21b8: mov x0, x19
6ea21bc: strb w28, [sp, #0x10]
6ea21c0: bl #0x6ea4ba8
6ea21c4: ldr x8, [x0]
6ea21c8: mov w1, w25
6ea21cc: mov x2, x20
6ea21d0: ldr x8, [x8, #0x18]
6ea21d4: blr x8
6ea21d8: add w28, w28, #1
6ea21dc: cmp w27, w28
6ea21e0: b.ne #0x6ea21b4
6ea21e4: cmp w25, #0
6ea21e8: fmov s0, s8
6ea21ec: cset w8, eq
6ea21f0: and w5, w21, #1
6ea21f4: and w4, w8, w23
6ea21f8: mov w0, wzr
6ea21fc: mov w1, #1
6ea2200: mov x2, x20
6ea2204: mov x3, x24
6ea2208: bl #0x6ea0958
6ea220c: mov w28, wzr
6ea2210: add x1, sp, #0xc
6ea2214: mov x0, x19
6ea2218: strb w28, [sp, #0xc]
6ea221c: bl #0x6ea4ba8
6ea2220: ldr x8, [x0]
6ea2224: mov w1, w25
6ea2228: mov x2, x20
6ea222c: ldr x8, [x8, #0x20]
6ea2230: blr x8
6ea2234: tbnz w0, #0, #0x6ea22d0
6ea2238: add w28, w28, #1
6ea223c: cmp w27, w28
6ea2240: b.ne #0x6ea2210
6ea2244: mov w28, wzr
6ea2248: add x1, sp, #8
6ea224c: mov x0, x19
6ea2250: strb w28, [sp, #8]
6ea2254: bl #0x6ea4ba8
6ea2258: ldr x8, [x0]
6ea225c: mov w1, w25
6ea2260: mov x2, x20
6ea2264: ldr x8, [x8, #0x28]
6ea2268: blr x8
6ea226c: add w28, w28, #1
6ea2270: cmp w27, w28
6ea2274: b.ne #0x6ea2248
6ea2278: add w25, w25, #1
6ea227c: cmp w25, w22
6ea2280: b.ne #0x6ea21b0
6ea2284: b #0x6ea22d0
6ea2288: cmp w22, #1
6ea228c: b.lt #0x6ea2304
6ea2290: fmov s0, #1.00000000
6ea2294: fdiv s8, s0, s8
6ea2298: mov w25, wzr
6ea229c: cmp w25, #0
6ea22a0: fmov s0, s8
6ea22a4: cset w8, eq
6ea22a8: and w5, w21, #1
6ea22ac: and w4, w8, w23
6ea22b0: mov w0, wzr
6ea22b4: mov w1, #1
6ea22b8: mov x2, x20
6ea22bc: mov x3, x24
6ea22c0: bl #0x6ea0958
6ea22c4: add w25, w25, #1
6ea22c8: cmp w22, w25
6ea22cc: b.ne #0x6ea229c
6ea22d0: cbz w27, #0x6ea2304
6ea22d4: mov w21, wzr
6ea22d8: add x1, sp, #4
6ea22dc: mov x0, x19
6ea22e0: strb w21, [sp, #4]
6ea22e4: bl #0x6ea4ba8
6ea22e8: ldr x8, [x0]
6ea22ec: mov x1, x20
6ea22f0: ldr x8, [x8, #0x30]
6ea22f4: blr x8
6ea22f8: add w21, w21, #1
6ea22fc: cmp w27, w21
6ea2300: b.ne #0x6ea22d8
6ea2304: ldr x8, [x26, #0x28]
6ea2308: ldr x9, [sp, #0x18]
6ea230c: cmp x8, x9
6ea2310: b.ne #0x6ea2338
6ea2314: ldp x20, x19, [sp, #0x80]
6ea2318: ldp x22, x21, [sp, #0x70]
6ea231c: ldp x24, x23, [sp, #0x60]
6ea2320: ldp x26, x25, [sp, #0x50]
6ea2324: ldp x28, x27, [sp, #0x40]
6ea2328: ldp x29, x30, [sp, #0x30]
6ea232c: ldr d8, [sp, #0x20]
6ea2330: add sp, sp, #0x90
6ea2334: ret 
6ea2338: bl #0x8b35290
