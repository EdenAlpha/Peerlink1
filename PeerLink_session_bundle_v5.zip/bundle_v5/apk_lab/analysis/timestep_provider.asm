6813eb8: fmov s0, #27.00000000
6813ebc: ret 
