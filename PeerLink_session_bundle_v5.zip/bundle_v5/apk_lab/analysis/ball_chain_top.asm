6ea1e90: stp x29, x30, [sp, #-0x40]!
6ea1e94: str x28, [sp, #0x10]
6ea1e98: stp x22, x21, [sp, #0x20]
6ea1e9c: stp x20, x19, [sp, #0x30]
6ea1ea0: mov x29, sp
6ea1ea4: sub sp, sp, #0x320
6ea1ea8: mrs x22, tpidr_el0
6ea1eac: mov x19, x0
6ea1eb0: ldr x8, [x22, #0x28]
6ea1eb4: sub x0, x29, #0x60
6ea1eb8: mov w20, w2
6ea1ebc: mov x21, x1
6ea1ec0: stur x8, [x29, #-8]
6ea1ec4: bl #0x6ea1fc4
6ea1ec8: add x0, sp, #0x188
6ea1ecc: mov x1, x21
6ea1ed0: bl #0x6ea1fdc
6ea1ed4: add x0, sp, #0x38
6ea1ed8: mov x1, x21
6ea1edc: mov w2, w20
6ea1ee0: bl #0x6ea2010
6ea1ee4: add x0, sp, #0x18
6ea1ee8: mov x1, x21
6ea1eec: bl #0x6ea2064
6ea1ef0: mov x0, sp
6ea1ef4: mov x1, x21
6ea1ef8: bl #0x6ea20a4
6ea1efc: sub x0, x29, #0x60
6ea1f00: add x1, sp, #0x188
6ea1f04: bl #0x6ea20d8
6ea1f08: sub x0, x29, #0x60
6ea1f0c: add x1, sp, #0x38
6ea1f10: bl #0x6ea20d8
6ea1f14: sub x0, x29, #0x60
6ea1f18: add x1, sp, #0x18
6ea1f1c: bl #0x6ea20d8
6ea1f20: sub x0, x29, #0x60
6ea1f24: mov x1, sp
6ea1f28: bl #0x6ea20d8
6ea1f2c: bl #0x6ea0874
6ea1f30: add x8, x0, #8
6ea1f34: cmp x0, #0
6ea1f38: csel x21, xzr, x8, eq
6ea1f3c: bl #0x6813eb8
6ea1f40: adrp x8, #0x98dd000
6ea1f44: sub x0, x29, #0x60
6ea1f48: mov x1, x19
6ea1f4c: mov x2, x21
6ea1f50: mov w3, #1
6ea1f54: mov w5, w20
6ea1f58: ldr x8, [x8, #0xdc8]
6ea1f5c: ldr w4, [x8]
6ea1f60: add x8, sp, #0x60
6ea1f64: bl #0x6ea20fc
6ea1f68: add x1, sp, #0x60
6ea1f6c: mov x0, x19
6ea1f70: mov w2, #0x128
6ea1f74: bl #0x8b35300
6ea1f78: mov x0, sp
6ea1f7c: bl #0x6ea2488
6ea1f80: add x0, sp, #0x18
6ea1f84: bl #0x6ea2488
6ea1f88: add x0, sp, #0x38
6ea1f8c: bl #0x6ea2488
6ea1f90: add x0, sp, #0x188
6ea1f94: bl #0x6ea2488
6ea1f98: ldr x8, [x22, #0x28]
6ea1f9c: ldur x9, [x29, #-8]
6ea1fa0: cmp x8, x9
6ea1fa4: b.ne #0x6ea1fc0
6ea1fa8: add sp, sp, #0x320
6ea1fac: ldp x20, x19, [sp, #0x30]
6ea1fb0: ldp x22, x21, [sp, #0x20]
6ea1fb4: ldr x28, [sp, #0x10]
6ea1fb8: ldp x29, x30, [sp], #0x40
6ea1fbc: ret 
6ea1fc0: bl #0x8b35290
