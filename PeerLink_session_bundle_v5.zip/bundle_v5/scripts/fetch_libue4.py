#!/usr/bin/env python3
"""Fetch config.arm64_v8a.apk from the .apks bundle and extract libUE4.so.

Reuses the surgical ranged downloader; then walks the inner APK's central
directory to locate lib/arm64-v8a/libUE4.so and writes it to
/home/z/my-project/apk_lab/libUE4.so.
"""
import os
import struct
import sys
import zipfile

sys.path.insert(0, '/home/z/my-project/scripts')
import apks_surgical_download as D

OUT_DIR = '/home/z/my-project/apk_lab/apks'
TARGET_MEMBER = 'config.arm64_v8a.apk'
LIB_NAME = 'lib/arm64-v8a/libUE4.so'
DEST = '/home/z/my-project/apk_lab/libUE4.so'


def main():
    D.get_total()
    entries = D.parse_central_dir()
    ent = next(e for e in entries if e['name'] == TARGET_MEMBER)
    path = D.download_member(ent, dest_name=TARGET_MEMBER)
    print('downloaded:', path, os.path.getsize(path))

    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        assert LIB_NAME in names, [n for n in names if 'libUE4' in n]
        with z.open(LIB_NAME) as fsrc, open(DEST, 'wb') as fdst:
            while True:
                chunk = fsrc.read(16 * 1024 * 1024)
                if not chunk:
                    break
                fdst.write(chunk)
    print('extracted:', DEST, os.path.getsize(DEST))


if __name__ == '__main__':
    main()
