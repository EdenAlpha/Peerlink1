#!/usr/bin/env python3
"""Decode the MatchMain state machine at 0x69917d8: jump table + PLT resolution."""
import json
import struct

LIB = '/home/z/my-project/apk_lab/libUE4.so'
plt_map = json.load(open('/home/z/my-project/apk_lab/analysis/plt_map.json'))

f = open(LIB, 'rb')


def read(off, n):
    f.seek(off)
    return f.read(n)


def plt(addr):
    e = plt_map.get(hex(addr))
    if e:
        return e['sym'] + (' [int]' if e.get('internal') else '')
    return None


# jump table: adrp x10, 0xc69000; add x10, x10, #0x522 -> 0xc69522
TABLE = 0xc69522
JUMP_BASE = 0x6991848
entries = read(TABLE, 11)
print('state byte -> handler:')
handlers = {}
for state in range(11):
    off = entries[state]
    target = JUMP_BASE + off * 4
    handlers[state] = target
    print(f'  state {state:2d}: off=0x{off:02x} -> 0x{target:x}')

print()
for a in (0x813fe80, 0x81604f4, 0x6836474, 0x8160680, 0x6988524, 0x6914c18, 0x66cf4cc, 0x66d058c, 0x68b5ed8):
    s = plt(a)
    print(f'0x{a:x} -> {s if s else "(internal fn)"}')

# which state falls into bl 0x69919e0 (at 0x69918a4)?
# case at 0x699187c falls through into it. find handler whose block contains/flows to 0x69918a4
print()
print('handler blocks of interest:')
for st, t in handlers.items():
    print(f'  state {st}: 0x{t:x}')
