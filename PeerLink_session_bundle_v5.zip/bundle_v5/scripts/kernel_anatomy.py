#!/usr/bin/env python3
"""Anatomical dissection of the ball physics kernel chain.

Functions: 0x6ea1e90 (top) -> 0x6ea20fc (mid) -> 0x6ea0958 (kernel)
Goals:
  - calling convention: which registers are read-before-write (args) at kernel entry
  - all direct BL callees
  - all global data refs (adrp+add/ldr)
  - FP instruction census + float constants (physics constants!)
  - call-site argument setup at each chain level

Output: apk_lab/analysis/kernel_anatomy.json + .asm dumps
"""
import json, os
import numpy as np
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN, CS_AC_READ, CS_AC_WRITE
from capstone.arm64_const import ARM64_OP_REG, ARM64_OP_IMM

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'
os.makedirs(AN, exist_ok=True)

f = open(SO, 'rb')
elf = ELFFile(f)
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        fl = seg['p_flags']
        loads.append(dict(vaddr=seg['p_vaddr'], memsz=seg['p_memsz'], filesz=seg['p_filesz'],
                          offset=seg['p_offset'], perms=('r' if fl & 4 else '-') + ('w' if fl & 2 else '-') + ('x' if fl & 1 else '-')))
TEXT = [l for l in loads if 'x' in l['perms']][0]
TV, TSZ = TEXT['vaddr'], TEXT['filesz']
fdata = open(SO, 'rb').read()

def v2o(v):
    for l in loads:
        if l['vaddr'] <= v < l['vaddr'] + l['filesz']:
            return v - l['vaddr'] + l['offset']
    return None

bl = np.load(f'{AN}/bl_map.npz')
entries = np.sort(np.unique(bl['bl_target']))
ad = np.load(f'{AN}/adrp_map.npz')

def fnext(entry):
    i = np.searchsorted(entries, entry)
    return int(entries[i + 1]) if i + 1 < len(entries) else TV + TSZ

md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
md.detail = True

def analyze(fn, name):
    end = fnext(fn)
    o = v2o(fn)
    code = fdata[o:o + (end - fn)]
    insns = list(md.disasm(code, fn))
    out = {'name': name, 'entry': hex(fn), 'end': hex(end), 'size': end - fn,
           'n_insns': len(insns), 'callees': [], 'globals': [], 'float_consts': [],
           'fp_census': {}, 'first_reads': [], 'blr_sites': [], 'asm_file': f'{AN}/{name}.asm'}
    with open(out['asm_file'], 'w') as fh:
        for i in insns:
            fh.write(f'{i.address:x}: {i.mnemonic} {i.op_str}\n')
    # register read-before-write tracking (first 60 insns)
    written = set()
    for i in insns[:60]:
        m = i.mnemonic
        if m in ('blr', 'br', 'ret', 'b'):
            continue
        ops = i.operands
        # reads: all regs in operands except the destination of writes
        for op in ops:
            if op.type == ARM64_OP_REG:
                r = i.reg_name(op.reg)
                if m in ('ldr', 'ldur', 'ldrsw', 'ldrb', 'ldrh', 'ldp') and op.access == CS_AC_WRITE:
                    continue
                if m in ('str', 'stur', 'sturb', 'strh', 'stp') and op.access == CS_AC_READ:
                    pass
                if r not in written and not r.startswith('w') and not r.startswith('x') is False:
                    pass
        if m in ('ldr', 'ldp'):
            # dest regs are reads of memory, writes of reg
            for op in ops:
                if op.type == ARM64_OP_REG and op.access == CS_AC_WRITE:
                    written.add(i.reg_name(op.reg))
        elif m in ('mov', 'fmov', 'add', 'sub', 'mul', 'adr', 'adrp', 'ldr', 'ldrsw', 'sxtw', 'lsl',
                   'orr', 'and', 'eor', 'madd', 'msub', 'cmp', 'fcvt', 'scvtf', 'ucvtf', 'fadd',
                   'fsub', 'fmul', 'fdiv', 'fneg', 'sqrtd', 'sqrt', 'fmadd', 'fmsub', 'movz', 'movk',
                   'cset', 'csel', 'csetm', 'ubfx', 'sbfx', 'extr', 'rbit', 'clz', 'mvn', 'neg'):
            for op in ops:
                if op.type == ARM64_OP_REG and op.access == CS_AC_WRITE:
                    written.add(i.reg_name(op.reg))
    # first arg candidates: x0-x7 / d0-d7 / w0-w7 read before written
    reads = {}
    written2 = set()
    for i in insns[:80]:
        for op in i.operands:
            if op.type == ARM64_OP_REG:
                r = i.reg_name(op.reg)
                if op.access in (CS_AC_READ, CS_AC_WRITE|CS_AC_READ) and r not in written2:
                    reads.setdefault(r, i.address)
                if op.access in (CS_AC_WRITE, CS_AC_WRITE|CS_AC_READ):
                    written2.add(r)
    args = [r for r in ['x0', 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7', 'w0', 'w1', 'w2', 'w3',
                        'd0', 'd1', 's0', 's1', 's2', 's3'] if r in reads]
    out['first_reads'] = {r: hex(a) for r, a in sorted(reads.items()) if r in args}

    # BL callees, BLR sites, globals, float consts, census
    import collections
    census = collections.Counter()
    for i in insns:
        m = i.mnemonic
        census[m] += 1
        if m == 'bl':
            out['callees'].append(hex(i.operands[0].imm))
        elif m in ('blr', 'br'):
            out['blr_sites'].append((hex(i.address), i.op_str))
        elif m == 'fmov':
            # fmov s0, #2.0 etc.
            if '#' in i.op_str and ('s' in i.op_str.split(',')[0].strip() or 'd' in i.op_str.split(',')[0].strip()):
                out['float_consts'].append((hex(i.address), i.op_str))
        elif m == 'adrp':
            pass  # handled by adrp map join
    out['fp_census'] = {k: v for k, v in census.items() if k.startswith('f') or k in ('scvtf', 'ucvtf', 'fcvt', 'fcvtzs', 'fcvtzu')}
    # globals via adrp_map
    lo = np.searchsorted(ad['ref_site'], fn, 'left')
    hi = np.searchsorted(ad['ref_site'], fn + (end - fn), 'right')
    out['globals'] = [(hex(int(s)), chr(int(k)), hex(int(t))) for s, t, k in
                      zip(ad['ref_site'][lo:hi], ad['ref_target'][lo:hi], ad['ref_kind'][lo:hi])]
    return out

results = {}
for fn, name in [(0x6ea0958, 'ball_kernel'), (0x6ea20fc, 'ball_chain_mid'),
                 (0x6ea1e90, 'ball_chain_top'), (0x6e938a0, 'ball_update_entry'),
                 (0x6d82418, 'ball_state_ctor'), (0x6813eb8, 'timestep_provider')]:
    results[name] = analyze(fn, name)
    r = results[name]
    print(f'\n=== {name} @ {r["entry"]} size={r["size"]:,} insns={r["n_insns"]:,} ===')
    print(f'  arg-candidate first reads: {r["first_reads"]}')
    print(f'  BL callees ({len(r["callees"])}): {r["callees"][:12]}')
    print(f'  BLR/BR sites ({len(r["blr_sites"])}): {r["blr_sites"][:6]}')
    print(f'  globals ({len(r["globals"])}): {r["globals"][:12]}')
    print(f'  FP census: {dict(sorted(r["fp_census"].items())[:15])}')
    print(f'  float consts: {r["float_consts"][:15]}')

json.dump(results, open(f'{AN}/kernel_anatomy.json', 'w'), indent=1)
print('\nJSON + .asm dumps ->', AN)
