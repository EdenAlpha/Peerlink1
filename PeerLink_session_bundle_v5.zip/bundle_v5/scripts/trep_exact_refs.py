#!/usr/bin/env python3
"""M5.1d: exact string starts for replay paths -> reloc addend hunt ->
the pointer table that holds them.
"""
import numpy as np
import json

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'
data = open(SO, 'rb').read()

from elftools.elf.elffile import ELFFile
f = open(SO, 'rb')
elf = ELFFile(f)
loads = [(s['p_vaddr'], s['p_memsz'], s['p_filesz'], s['p_offset'])
         for s in elf.iter_segments() if s['p_type'] == 'PT_LOAD']
loads.sort()


def off2va(off):
    for va, mem, fsz, fo in loads:
        if fo <= off < fo + fsz:
            return va + (off - fo)
    return None


def va2off(va):
    for va_, mem, fsz, fo in loads:
        if va_ <= va < va_ + mem:
            return fo + (va - va_)
    return None


# find every occurrence of replay-path fragments, walk back to NUL = true start
frags = [b'cpk_dat/common/match/tutorial_replay/',
         b'cpk_dat/common/match/gimmick_replay/',
         b'cpk_dat/common/match/path_to_glory_replay/']
starts = {}
for frag in frags:
    pos = 0
    while True:
        i = data.find(frag, pos)
        if i < 0:
            break
        pos = i + 1
        s0 = data.rfind(b'\x00', max(0, i - 64), i) + 1
        e0 = data.find(b'\x00', i, i + 128)
        va = off2va(s0)
        if va is None:
            continue
        starts[va] = data[s0:e0].decode('utf-8', 'replace')

print(f'{len(starts)} replay-path strings with true starts')
for va in sorted(starts)[:20]:
    print(f'  {va:#x}: {starts[va]!r}')

z = np.load(f'{AN}/packed_relocs.npz', allow_pickle=True)
off, sym, rtype, addend = z['offset'], z['sym'], z['rtype'], z['addend']

vaset = set(starts)
mask = np.isin(addend, list(vaset))
print(f'\nrelocs addend == true string starts: {mask.sum()}')
res = {}
for o, a in zip(off[mask], addend[mask]):
    res.setdefault(int(a), []).append(int(o))
for a in sorted(res):
    print(f'  str {a:#x} ({starts[a][:60]!r}) referenced by reloc at:')
    for o in res[a][:6]:
        print(f'      {o:#x}')

json.dump({hex(a): [hex(o) for o in lst] for a, lst in res.items()},
          open(f'{AN}/replay_path_refs.json', 'w'), indent=1)
json.dump({hex(k): v for k, v in starts.items()},
          open(f'{AN}/replay_path_strings.json', 'w'), indent=1)
print('JSON -> replay_path_refs.json / replay_path_strings.json')
