#!/usr/bin/env python3
"""Remote inner-APK inspector: parse the central directory of a STORED member
of the .apks bundle (e.g. pad_it_0.apk) using ranged requests only, then
selectively download + inflate chosen members (e.g. .cpk data files).

Usage:
  python inner_apk_remote.py list <member-name>
  python inner_apk_remote.py pull <member-name> <inner-path> [dest]
"""
import io
import json
import os
import struct
import sys
import zlib

sys.path.insert(0, '/home/z/my-project/scripts')
from apks_surgical_download import (get_total, parse_central_dir, fetch_range,
                                    get_local_header, OUT, TOTAL)

MANIFEST = f'{OUT}/apks_manifest.json'


def get_entry(name):
    entries = json.load(open(MANIFEST))
    for e in entries:
        if e['name'] == name:
            return e
    raise KeyError(name)


def inner_cd(name):
    """Parse the central directory of an inner APK that lives at remote range."""
    e = get_entry(name)
    data_off = get_local_header(e)   # remote offset of inner apk start
    n = e['csize']
    tail_len = min(4 * 1024 * 1024, n)
    tail = fetch_range(data_off + n - tail_len, tail_len)
    eocd = None
    for i in range(len(tail) - 22, -1, -1):
        if tail[i:i + 4] == b'PK\x05\x06':
            eocd = i
            break
    if eocd is None:
        raise RuntimeError('inner EOCD not found')
    (cd_size, cd_off) = struct.unpack_from('<II', tail, eocd + 12)
    (n_ent,) = struct.unpack_from('<H', tail, eocd + 10)
    print(f'inner EOCD: {n_ent} entries, cd_size={cd_size:,} cd_off={cd_off:#x}')
    tail_start = n - tail_len            # offset of tail within inner apk
    cd_start_rel = eocd - cd_size        # cd start within tail, if fully inside
    if cd_start_rel >= 0:
        cd = tail[cd_start_rel:eocd]
    else:
        # fetch the whole CD from remote
        cd = fetch_range(data_off + cd_off, cd_size)
    entries = []
    p = 0
    while p + 46 <= len(cd) and cd[p:p + 4] == b'PK\x01\x02':
        method = struct.unpack_from('<H', cd, p + 10)[0]
        (csize, usize) = struct.unpack_from('<II', cd, p + 20)
        (name_len, extra_len, comm_len) = struct.unpack_from('<HHH', cd, p + 28)
        lho = struct.unpack_from('<I', cd, p + 42)[0]
        iname = cd[p + 46:p + 46 + name_len].decode('utf-8', 'replace')
        if extra_len:
            ex = cd[p + 46 + name_len:p + 46 + name_len + extra_len]
            q = 0
            while q + 4 <= len(ex):
                hid, hsz = struct.unpack_from('<HH', ex, q)
                if hid == 0x0001:
                    if usize == 0xFFFFFFFF:
                        usize = struct.unpack_from('<Q', ex, q + 8)[0]
                    if csize == 0xFFFFFFFF:
                        csize = struct.unpack_from('<Q', ex, q + 16)[0]
                q += 4 + hsz
        entries.append(dict(name=iname, method=method, csize=csize, usize=usize, lho=lho))
        p += 46 + name_len + extra_len + comm_len
    print(f'parsed {len(entries)} inner entries')
    for e2 in entries:
        print(f"  {e2['name']}  method={e2['method']} csize={e2['csize']:,} usize={e2['usize']:,}")
    return data_off, entries


def pull(name, inner_path, dest):
    e = get_entry(name)
    data_off = get_local_header(e)
    entries = inner_cd(name)[1]
    tgt = [x for x in entries if x['name'] == inner_path]
    if not tgt:
        raise KeyError(inner_path)
    tgt = tgt[0]
    # inner local header
    lh = fetch_range(data_off + tgt['lho'], 30)
    assert lh[:4] == b'PK\x03\x04'
    (name_len, extra_len) = struct.unpack_from('<HH', lh, 26)
    inner_data_off = data_off + tgt['lho'] + 30 + name_len + extra_len
    n = tgt['csize']
    print(f"pulling {inner_path} ({n:,} bytes compressed, method {tgt['method']})")
    raw = b''
    pos = 0
    CH = 96 * 1024 * 1024
    while pos < n:
        ln = min(CH, n - pos)
        raw += fetch_range(inner_data_off + pos, ln)
        pos += ln
        print(f'  {pos:,}/{n:,}', flush=True)
    if tgt['method'] == 8:
        data = zlib.decompress(raw, -15)
    else:
        data = raw
    assert len(data) == tgt['usize'], f'{len(data)} != {tgt["usize"]}'
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    open(dest, 'wb').write(data)
    print(f'saved {dest} ({len(data):,} bytes)')
    return dest


if __name__ == '__main__':
    if TOTAL is None:
        get_total()
    cmd = sys.argv[1]
    if cmd == 'list':
        inner_cd(sys.argv[2])
    elif cmd == 'pull':
        pull(sys.argv[2], sys.argv[3], sys.argv[4])
