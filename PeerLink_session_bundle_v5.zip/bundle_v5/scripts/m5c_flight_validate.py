#!/usr/bin/env python3
"""M5c: flight validation through the REAL per-frame continuous tick.

Protocol (decoded this session):
  driver_B per lane: 0x6e92ce8(module, s0=dt_timescale, w1=install_gate)
  0x6e92ce8: [module+8] += s0; frame boundary when floor crosses;
             if crossed: 0x6e93adc(module) install gate (via [module+0x2F8]);
             0x6ea233c(module+0x158, ctx, gate) = ONE PURE w4=0 substep
             with dt=1/27 HARDCODED (0x6813eb8) — the .rep record stream.
  The state chain lives at +0x158 and SELF-ADVANCES.

Install: kick state (pos/vel/quat from .rep f48) directly into +0x158,
[module+0x2F8]=0 (no installer), then 75 frames of 0x6e92ce8(1.0, 0).
Compare +0x158 per frame vs .rep frames 49..123 at i16/256.
"""
import json
import os
import struct
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ball_object_run import BallWorld, rd_state, state_vec, STATE_SZ
from unicorn.arm64_const import *

OUT = '/home/z/my-project/apk_lab/analysis/m5c_flight_validate.json'
REP = ('/home/z/my-project/apk_lab/cpk/dt270_out/common/match/'
       'tutorial_replay/tutorial_replay_shooting_02.rep')
HDR, REC = 44400, 10976
A_CONT_TICK = 0x6e92ce8
A_RECORDER_WRITE = 0x6a6b604
F_FIRST, F_LAST = 48, 123


def rep_slot0(f):
    d = open(REP, 'rb').read()
    base = HDR + f * REC
    blk = d[base + 0x2D4:base + 0x2D4 + 0x1C]
    q = struct.unpack_from('<4f', blk, 0)
    x, y, z = struct.unpack_from('<hhh', blk, 0x10)
    return {'quat': q, 'pos': (x / 256, y / 256, z / 256), 'raw': blk}


def install_chain(world, modA, P0, V0, quat, mode, air):
    core = world.core
    s = bytearray(STATE_SZ)
    struct.pack_into('<3f', s, 0x000, *P0)
    struct.pack_into('<3f', s, 0x00C, *V0)
    struct.pack_into('<3f', s, 0x018, 0.0, 0.0, 0.0)
    s[0x90] = 1
    s[0x91] = 6
    struct.pack_into('<i', s, 0x094, 0)
    struct.pack_into('<4f', s, 0x098, *quat)
    struct.pack_into('<i', s, 0x08C, mode)
    core.uc.mem_write(modA + 0x158, bytes(s))     # THE CHAIN STATE
    core.write_u64(modA + 0x2F8, 0)               # no installer
    core.write_u32(modA + 0x8, 0)                 # time accumulator
    core.uc.mem_write(world.params, struct.pack('<f', air))
    world.set_N(3)


def run_flight(world, modA, n, mode, air, w1=0):
    core = world.core
    recs = []

    def wcb(uc, _):
        x2 = uc.reg_read(UC_ARM64_REG_X2)
        w1v = uc.reg_read(UC_ARM64_REG_X1) & 0xFFFFFFFF
        src = core.safe_read(x2, 0x1C) if x2 else b''
        recs.append((w1v, src))

    wk = core.watch(A_RECORDER_WRITE, wcb, name='rec')
    positions, faults = [], None
    for k in range(n):
        r = core.call(A_CONT_TICK, x0=modA, s0=1.0, w1=w1)
        if r['error']:
            faults = (k, r['error'])
            break
        positions.append(state_vec(rd_state(core, modA + 0x158)))
    core.unwatch(wk)
    return positions, recs, faults


def main():
    oracle = {f: rep_slot0(f) for f in range(F_FIRST, F_LAST + 2)}
    o48 = oracle[F_FIRST]
    p48 = o48['pos']
    p49 = oracle[F_FIRST + 1]['pos']
    v_imp = tuple((np.array(p49) - np.array(p48)) * 27.0)
    v0 = (v_imp[0], v_imp[1] + 9.80665 / 27.0, v_imp[2])

    world = BallWorld(verbose=True)
    world.construct()
    modA = world.ball

    results = {}
    for name, V0, mode, air in [
        ('implied_v0_air0.399_mode8', v0, 8, 0.399),
        ('implied_v0_air1.0_mode8', v0, 8, 1.0),
        ('m3fit_v0_air0.399_mode8', (24.76, 5.20, -4.70), 8, 0.399),
    ]:
        install_chain(world, modA, p48, V0, o48['quat'], mode, air)
        positions, recs, faults = run_flight(world, modA,
                                             F_LAST - F_FIRST, mode, air)
        n = len(positions)
        errs = np.array([np.array(positions[i]) -
                         np.array(oracle[F_FIRST + 1 + i]['pos'])
                         for i in range(n)]) if n else np.zeros((0, 3))
        rms = float(np.sqrt((errs ** 2).sum(axis=1).mean())) if n else 0
        maxe = float(np.abs(errs).max()) if n else 0
        nq = sum(1 for i in range(n)
                 if [int(round(v * 256)) for v in positions[i]] ==
                 [int(round(v * 256)) for v in oracle[F_FIRST + 1 + i]['pos']])
        results[name] = {'fault': faults, 'n': n, 'rms_m': rms,
                         'max_err_m': maxe, 'exact_i16': nq,
                         'rec_calls': len(recs), 'v0': V0}
        print(f'[{name}] fault={faults} n={n} rms={rms*100:.2f}cm '
              f'max={maxe*100:.1f}cm exact16={nq}/{n} recs={len(recs)}')
        if n:
            print(f'   f{F_FIRST+1}: pred={tuple(round(x,3) for x in positions[0])} '
                  f'oracle={oracle[F_FIRST+1]["pos"]}')
            mid = n // 2
            print(f'   f{F_FIRST+1+mid}: pred={tuple(round(x,3) for x in positions[mid])} '
                  f'oracle={oracle[F_FIRST+1+mid]["pos"]}')
            print(f'   f{F_FIRST+n}: pred={tuple(round(x,3) for x in positions[-1])} '
                  f'oracle={oracle[F_FIRST+n]["pos"]}')

    # recorder record bytes for the best variant: compare vs .rep raw
    install_chain(world, modA, p48, v0, o48['quat'], 8, 0.399)
    positions, recs, faults = run_flight(world, modA, F_LAST - F_FIRST, 8, 0.399)
    rec_compare = []
    for i, (idx, src) in enumerate(recs[:80]):
        b = src
        pos = struct.unpack_from('<3f', b, 0)
        q = struct.unpack_from('<4f', b, 12)
        rec_compare.append({'i': i, 'idx': idx, 'pos': pos, 'quat': q,
                            'hex': b.hex()})
    results['recorder_records'] = rec_compare
    json.dump(results, open(OUT, 'w'), indent=1, default=float)
    print(f'JSON -> {OUT}')


if __name__ == '__main__':
    main()
