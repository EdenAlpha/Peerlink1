#!/usr/bin/env python3
"""Cross the virtual dispatch wall.

1. Full source-path string mine: every 'G:\\PES22HC...' string -> vaddr ->
   referencing functions (via adrp_map) -> full source map (file -> funcs).
2. Vtable slot discovery: RELATIVE relocs whose ADDEND equals a known
   driver/tick function -> the data address where that function pointer is
   stored (vtable slot / task table entry). Then find the vtable base and
   the code that references the slot region.
3. From each vtable, dump sibling slots (other virtuals of the same class)
   and find dispatch sites: functions that adrp-reference the vtable base
   (constructors) and blr through the slot offset.

Output: apk_lab/analysis/wall_cross.json + console.
"""
import json
import re
import numpy as np
from elftools.elf.elffile import ELFFile

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'

f = open(SO, 'rb')
elf = ELFFile(f)
loads = [(s['p_vaddr'], s['p_filesz'], s['p_offset'])
         for s in elf.iter_segments() if s['p_type'] == 'PT_LOAD' and s['p_filesz']]


def v2o(v):
    for va, fsz, off in loads:
        if va <= v < va + fsz:
            return v - va + off
    return None


def o2v(o):
    for va, fsz, off in loads:
        if off <= o < off + fsz:
            return o - off + va
    return None


data = open(SO, 'rb').read()

# ---------- 1. full source string mine ----------
print('=== 1. SOURCE PATH STRINGS ===')
pat = re.compile(rb'G:\\PES22HC[ -~]{3,180}?\.cpp\x00')
srcmap = []
for m in pat.finditer(data):
    va = o2v(m.start())
    if va:
        srcmap.append((va, m.group()[:-1].decode()))
print(f'found {len(srcmap)} .cpp path strings')

ad = np.load(f'{AN}/adrp_map.npz')
rs, rt = ad['ref_site'].astype(np.int64), ad['ref_target'].astype(np.int64)
aorder = np.argsort(rt)
rt_s, rs_s = rt[aorder], rs[aorder]


def refs_to(t):
    i, j = np.searchsorted(rt_s, t, 'left'), np.searchsorted(rt_s, t, 'right')
    return rs_s[i:j].tolist()


# func-start via fgraph entries (nearest entry <= site)
fg = np.load(f'{AN}/fgraph.npz')
ent = np.sort(fg['entries'].astype(np.int64))


def func_of(site):
    i = np.searchsorted(ent, site, 'right') - 1
    return int(ent[i]) if i >= 0 else None


file2funcs = {}
for va, s in srcmap:
    sites = refs_to(va)
    funcs = sorted(set(func_of(x) for x in sites if func_of(x)))
    if funcs:
        file2funcs[s] = [hex(x) for x in funcs]

# focus on pes/ game dirs
game = {k: v for k, v in file2funcs.items()
        if '\\pes\\Game\\' in k or '\\pes\\' in k}
print(f'strings with function refs: {len(file2funcs)} (game: {len(game)})')
for k in sorted(game):
    print(f'  {k.split("Source\\\\")[-1] if "Source\\\\" in k else k}: {game[k]}')

# ---------- 2. vtable slot discovery for driver functions ----------
print('\n=== 2. VTABLE SLOTS (reloc addend = func ptr) ===')
pr = np.load(f'{AN}/packed_relocs.npz')
roff, radd = pr['offset'].astype(np.int64), pr['addend'].astype(np.int64)
aorder2 = np.argsort(radd)
ra_s, ro_s = radd[aorder2], roff[aorder2]


def slots_for(func):
    i, j = np.searchsorted(ra_s, func, 'left'), np.searchsorted(ra_s, func, 'right')
    return ro_s[i:j].tolist()


DRIVERS = {
    'ball_construction': 0x6a35434,
    'driven_driver': 0x6a35688,
    'driver_A': 0x6a35978,
    'driver_B': 0x6a359f4,
    'driver_C': 0x6a36a64,
    'driver_D': 0x6a37c7c,
    'ball_update_entry': 0x6e938a0,
    'player_replay_writer': 0x728d7e0,
    'ball_replay_writer': 0x728d930,
    'match_cmd_user': 0x7bff91c,
    'rp_rand_seed_user': 0x7ceafc4,
}
slots = {}
for name, fn in DRIVERS.items():
    ss = slots_for(fn)
    slots[name] = [hex(s) for s in ss]
    print(f'  {name} {fn:#x}: {len(ss)} pointer slots {[hex(s) for s in ss[:8]]}')

# ---------- 3. vtable reconstruction around each slot ----------
print('\n=== 3. VTABLE CONTEXT ===')


def dump_around(slot, span_before=0x60, span_after=0x20):
    """Dump function pointers stored around a slot (vtable neighbors)."""
    lo, hi = slot - span_before, slot + span_after
    m = (roff >= lo) & (roff < hi)
    pairs = sorted(zip(roff[m].tolist(), radd[m].tolist()))
    return [(hex(o), hex(a)) for o, a in pairs]


for name in ('driven_driver', 'driver_B', 'ball_update_entry', 'player_replay_writer'):
    ss = [int(x, 16) for x in slots[name]][:3]
    for s in ss:
        ctx = dump_around(s)
        print(f'  {name} slot {s:#x}: {len(ctx)} ptrs around')
        for o, a in ctx:
            tag = ' <== DRIVER' if int(a, 16) == DRIVERS.get(name) else ''
            print(f'      {o}: {a}{tag}')
        # who references this region? (adrp refs into [s-0x60, s+0x20])
        i = np.searchsorted(rt_s, s - 0x100, 'left')
        j = np.searchsorted(rt_s, s + 0x100, 'right')
        refsites = rs_s[i:j].tolist()
        reffuncs = sorted(set(func_of(x) for x in refsites if func_of(x)))
        print(f'      refs into slot region from funcs: {[hex(x) for x in reffuncs[:12]]}')

json.dump({'file2funcs': file2funcs, 'slots': slots}, open(f'{AN}/wall_cross.json', 'w'), indent=1)
print('\nJSON ->', f'{AN}/wall_cross.json')
