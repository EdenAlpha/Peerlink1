#!/usr/bin/env python3
"""M5.3: find the .rep record writer/reader by size constants.
- 10976 (0x2AC0) record size, 44400 (0xAD90) header size
- 1200 (0x4B0) frame count near those
- movz/movk or cmp imm forms
"""
import numpy as np
import json

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'
data = open(SO, 'rb').read()

from elftools.elf.elffile import ELFFile
f = open(SO, 'rb')
elf = ELFFile(f)
loads = [(s['p_vaddr'], s['p_memsz'], s['p_filesz'], s['p_offset'])
         for s in elf.iter_segments() if s['p_type'] == 'PT_LOAD']
loads.sort()

entries = np.load(f'{AN}/fgraph2.npz', allow_pickle=True)['entries']
entries.sort()


def func_of(a):
    i = np.searchsorted(entries, a, 'right') - 1
    return int(entries[i])


# search for movz w, #0x2ac0 / #0xad90 (imm16) and literal pools
targets = {0x2AC0: 'rec_size_10976', 0xAD90: 'hdr_44400', 0x4B0: 'frames_1200'}
hits = {k: [] for k in targets}
for va, mem, fsz, fo in loads:
    seg = data[fo:fo + fsz]
    if len(seg) < 0x100000:
        continue
    words = np.frombuffer(seg, dtype='<u4')
    pc_base = va
    # movz wN, #imm16: (w & 0xFFE00000) == 0x52800000
    mz = (words & 0xFFE00000) == 0x52800000
    mz_imm = (words >> 5) & 0xFFFF
    for tgt in targets:
        m = mz & (mz_imm == tgt)
        for wi in np.nonzero(m)[0]:
            hits[tgt].append(pc_base + int(wi) * 4)
    # literal pool entries (u32 constants in text)
    for tgt in targets:
        m = words == tgt
        for wi in np.nonzero(m)[0]:
            hits[tgt].append(pc_base + int(wi) * 4)

fns = {k: {} for k in targets}
for k, sites in hits.items():
    for p in sites:
        fns[k].setdefault(func_of(p), []).append(p)

for k, name in targets.items():
    print(f'\n=== {name} ({k:#x}): {len(hits[k])} sites, {len(fns[k])} fns')
    for fs, ss in sorted(fns[k].items(), key=lambda kv: -len(kv[1]))[:15]:
        print(f'  func {fs:#x}: {len(ss)} sites {[hex(s) for s in ss[:5]]}')

# functions containing BOTH 0x2AC0 and 0xAD90 or (0x2AC0 and 0x4B0)
inter = set(fns[0x2AC0]) & set(fns[0xAD90])
print(f'\nfns with BOTH 10976 and 44400: {sorted(hex(x) for x in inter)}')
inter2 = set(fns[0x2AC0]) & set(fns[0x4B0])
print(f'fns with BOTH 10976 and 1200: {sorted(hex(x) for x in inter2)}')

json.dump({hex(k): {hex(fs): [hex(p) for p in ss] for fs, ss in v.items()}
           for k, v in fns.items()},
          open(f'{AN}/rep_writer_hits.json', 'w'), indent=1)
print('\nJSON -> rep_writer_hits.json')
