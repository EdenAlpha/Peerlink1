#!/usr/bin/env python3
"""MILESTONE 4: tick the ball module THROUGH the module manager (real path).

Photocopy increment: instead of calling ball_update_entry (0x6e938a0)
directly, build the real hierarchy and tick it exactly as the game does:

    match stub
      +0x3C98 -> module MANAGER (ctor 0x6a352c4, vtable 0x978d388)
                   +0x38 -> ball module A (0x14B8, w1=0)
                   +0x40 -> ball module B (0x14B8, w1=1)
    0x6a059b0(match)  ->  driver_C(0x6a36a64)(manager)
                          -> 6a35970(moduleA, 1) + 6a35688(mgr, 0, f3)

Validations:
  M0  manager construction clean (ctor 0x6a352c4 chain)
  M1  manager-tick runs without fault (the real per-frame path)
  M2  state propagation: does the driven driver install (0,0,0) or tick?
  M3  bit-exact: manager-path tick vs direct ball_update_entry tick
  M4  driven driver decode: 0x6a35688(mgr, w1, pos) semantics
"""
import json
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from uc_loader2 import EFootballCoreV2
from ball_object_run import BallWorld, rd_state, state_vec, RADIUS
from unicorn.arm64_const import *

OUT = '/home/z/my-project/apk_lab/analysis/match_core_run.json'

A_MGR_CTOR = 0x6a352c4       # manager ctor: vtable 0x978d388 @ +0, +0x18
A_MGR_CONSTRUCT = 0x6a35434  # full: module A/B alloc + ctors + first driven tick
A_UPDATE_BALL_MOD = 0x6a059b0  # match+0x3C98 -> manager -> driver_C
A_DRIVER_C = 0x6a36a64
A_DRIVEN = 0x6a35688
A_TICK = 0x6e938a0
A_BASE_CTOR = 0x6e92768
A_MOD_CTOR = 0x6e91da8

MATCH_SIZE = 0x8000
OFF_BALL_MGR = 0x3C98


def main():
    world = BallWorld(verbose=True)
    core = world.core
    res = {}

    # ---------------- M0: manager construction ----------------
    print('=== M0: manager ctor 0x6a352c4 ===')
    mgr = core.alloc(0x200, b'\0' * 0x200, name='ball_mgr')
    r = core.call(A_MGR_CTOR, x0=mgr)
    ok = not r['error']
    vt = struct.unpack_from('<Q', core.safe_read(mgr, 8), 0)[0] if ok else 0
    res['M0'] = {'pass': bool(ok), 'vtable': hex(vt),
                 'note': 'expect vtable 0x978d388'}
    print('[M0]', res['M0'])
    if not ok:
        fatal = [l for l in core._log if 'FAULT' in l or 'INVALID' in l]
        print('fatal:', fatal[-8:])
        json.dump(res, open(OUT, 'w'), indent=1)
        return

    # ---------------- construct module A via M2 path ----------------
    print('\n=== construct ball module A (M2 path), store at mgr+0x38 ===')
    modA = core.alloc(0x14B8, b'\0' * 0x14B8, name='ball_module_A')
    r = core.call(A_BASE_CTOR, x0=modA, w1=0)
    assert not r['error'], r
    holder = core.alloc(0x8000, b'\0' * 0x8000, name='holderA')
    core.write_u8(modA + 0x360, 1)
    core.write_u64(modA + 0x3A0, holder)
    r = core.call(A_MOD_CTOR, x0=modA, w1=0)
    assert not r['error'], r
    core.write_u64(mgr + 0x38, modA)
    print(f'   module A @ {modA:#x} -> [mgr+0x38]; +0x38/+0x40 after ctors:',
          hex(struct.unpack_from('<Q', core.safe_read(modA + 0x38, 8), 0)[0]),
          hex(struct.unpack_from('<Q', core.safe_read(modA + 0x40, 8), 0)[0]))

    # module B (w1=1)
    modB = core.alloc(0x14B8, b'\0' * 0x14B8, name='ball_module_B')
    r = core.call(A_BASE_CTOR, x0=modB, w1=1)
    assert not r['error'], r
    holderB = core.alloc(0x8000, b'\0' * 0x8000, name='holderB')
    core.write_u8(modB + 0x360, 1)
    core.write_u64(modB + 0x3A0, holderB)
    r = core.call(A_MOD_CTOR, x0=modB, w1=1)
    assert not r['error'], r
    core.write_u64(mgr + 0x40, modB)

    # ---------------- match stub ----------------
    match = core.alloc(MATCH_SIZE, b'\0' * MATCH_SIZE, name='match_stub')
    core.write_u64(match + OFF_BALL_MGR, mgr)

    # ---------------- M1: manager-path tick ----------------
    print('\n=== M1: 0x6a059b0(match) — the real per-frame path ===')
    world.set_N(3)
    # install a flight state into module A input
    world.ball = modA  # reuse BallWorld helpers on module A
    world.set_state((5.0, 3.0, -2.0), phys=1, sub=6)
    st_before = rd_state(core, modA + 0x30)
    st_out_before = rd_state(core, modA + 0x158)

    kernel_calls = []

    def kcb(uc, c):
        x2 = uc.reg_read(UC_ARM64_REG_X2)
        w4 = uc.reg_read(UC_ARM64_REG_X4) & 1
        kernel_calls.append((hex(x2), w4))

    wk = core.watch(0x6ea0958, kcb, name='kmon')
    r = core.call(A_UPDATE_BALL_MOD, x0=match)
    core.unwatch(wk)
    ok = not r['error']
    st_after_out = rd_state(core, modA + 0x158)
    st_after_in = rd_state(core, modA + 0x30)
    res['M1'] = {
        'pass': bool(ok), 'kernel_calls': kernel_calls,
        'in_state_changed': st_before != st_after_in,
        'out_state_changed': st_out_before != st_after_out,
    }
    print('[M1]', res['M1'])
    if not ok:
        fatal = [l for l in core._log if 'FAULT' in l or 'INVALID' in l]
        print('fatal tail:', fatal[-10:])
        json.dump(res, open(OUT, 'w'), indent=1)
        return

    # ---------------- M2: what did the manager tick do? ----------------
    pos_out = state_vec(st_after_out)
    pos_in = state_vec(st_after_in)
    res['M2'] = {
        'pos_in_after': pos_in, 'pos_out_after': pos_out,
        'pos_in_before': state_vec(st_before),
        'note': 'driver_C installs (0,0,0)+ticks; check semantics'
    }
    print('[M2]', res['M2'])

    # ---------------- M4: driven driver decode ----------------
    print('\n=== M4: 0x6a35688(mgr, w1, pos) semantics ===')
    # restore a clean flight state, then call driven with a distinct pos
    world.set_state((5.0, 3.0, -2.0), phys=1, sub=6)
    st0 = rd_state(core, modA + 0x30)
    kc2 = []
    wk = core.watch(0x6ea0958, lambda uc, c: kc2.append(1), name='kmon2')
    r = core.call(A_DRIVEN, x0=mgr, w1=0, s0=7.5, s1=1.25, s2=-3.5)
    core.unwatch(wk)
    st1 = rd_state(core, modA + 0x30)
    st1o = rd_state(core, modA + 0x158)
    res['M4'] = {'error': r['error'], 'kernel_calls': len(kc2),
                 'pos_in': state_vec(st1), 'pos_out': state_vec(st1o)}
    print('[M4]', res['M4'])

    # w1=1 variant
    world.set_state((5.0, 3.0, -2.0), phys=1, sub=6)
    kc3 = []
    wk = core.watch(0x6ea0958, lambda uc, c: kc3.append(1), name='kmon3')
    r2 = core.call(A_DRIVEN, x0=mgr, w1=1, s0=7.5, s1=1.25, s2=-3.5)
    core.unwatch(wk)
    st2 = rd_state(core, modA + 0x30)
    res['M4b'] = {'error': r2['error'], 'kernel_calls': len(kc3),
                  'pos_in': state_vec(st2)}
    print('[M4b]', res['M4b'])

    # ---------------- M3: bit-exact vs direct tick ----------------
    print('\n=== M3: manager-path tick vs direct ball_update_entry ===')
    world.set_N(3)
    world.set_state((5.0, 3.0, -2.0), phys=1, sub=6)
    # direct reference run
    st_direct_seq = []
    cur = rd_state(core, modA + 0x30)
    for t in range(3):
        core.uc.mem_write(modA + 0x30, cur)
        out = world.tick()
        st_direct_seq.append(out)
        cur = out
    # manager-path run (reset state identically)
    world.set_state((5.0, 3.0, -2.0), phys=1, sub=6)
    st_mgr_seq = []
    cur = rd_state(core, modA + 0x30)
    for t in range(3):
        core.uc.mem_write(modA + 0x30, cur)
        r = core.call(A_UPDATE_BALL_MOD, x0=match)
        assert not r['error'], r
        out = rd_state(core, modA + 0x158)
        st_mgr_seq.append(out)
        cur = out
    diffs = [sum(a != b for a, b in zip(x, y))
             for x, y in zip(st_direct_seq, st_mgr_seq)]
    res['M3'] = {'per_tick_diffs': diffs, 'pass': all(d == 0 for d in diffs),
                 'direct_y': [state_vec(x)[1] for x in st_direct_seq],
                 'mgr_y': [state_vec(x)[1] for x in st_mgr_seq],
                 'note': 'diffs may be nonzero: driver_C resets pos (decode M2)'}
    print('[M3]', res['M3'])

    json.dump(res, open(OUT, 'w'), indent=1, default=float)
    print('JSON ->', OUT)


if __name__ == '__main__':
    main()
