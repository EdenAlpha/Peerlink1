#!/usr/bin/env python3
"""v2: proper unicorn register constants. Log drag_fn(0x6ea1938) args:
x1 = state pointer (compare with ball+0x30 / ball+0x158), x3 = params,
s0 = dt. Dump the working state's ladder region. Then find the -1.0 writer
by watching writes to working_state+0x84."""
import struct
import sys

sys.path.insert(0, '/home/z/my-project/scripts')
from ball_object_run import BallWorld
from unicorn.arm64_const import (UC_ARM64_REG_X0, UC_ARM64_REG_X1,
                                 UC_ARM64_REG_X3, UC_ARM64_REG_S0)

A_DRAG_FN = 0x6ea1938
A_LADDER = 0x6ea555c
DT = 1.0 / 27.0


def f32(x):
    return struct.unpack('<f', struct.pack('<I', x & 0xffffffff))[0]


def main():
    world = BallWorld(verbose=False)
    world.construct()
    core = world.core
    ball = world.ball
    info = {'states': set(), 'params': set(), 'n': 0, 'ladder': 0}

    def drag_cb(uc, core_):
        x1 = uc.reg_read(UC_ARM64_REG_X1)
        x3 = uc.reg_read(UC_ARM64_REG_X3)
        s0 = f32(uc.reg_read(UC_ARM64_REG_S0))
        info['states'].add(x1)
        info['params'].add(x3)
        info['n'] += 1
        if info['n'] <= 3:
            b = bytes(core_.safe_read(x1, 0x128))
            ldr = struct.unpack_from('<6f', b, 0x74)
            mode = struct.unpack_from('<i', b, 0x8c)[0]
            phys, sub = b[0x90], b[0x91]
            print(f'  drag_fn #{info["n"]}: state={hex(x1)} params={hex(x3)} '
                  f'dt={s0:.6f}')
            print(f'    state ladder={[round(v,3) for v in ldr]} mode={mode} '
                  f'phys={phys} sub={sub}')

    def ladder_cb(uc, core_):
        info['ladder'] += 1
        if info['ladder'] > 300000:
            uc.emu_stop()

    w1 = core.watch(A_DRAG_FN, drag_cb, name='dragfn')
    w2 = core.watch(A_LADDER, ladder_cb, name='ladder')
    world.set_N(2)
    world.set_state((0, 3.0, 0), vel=(2.0, 0, 0), phys=1, sub=6)
    world.reset_kernel_ctx()
    for _ in range(4):
        world.tick_feedback()
    core.unwatch(w1)
    core.unwatch(w2)

    print(f'\nball base       = {hex(ball)}')
    print(f'ball+0x30 (in)  = {hex(ball+0x30)}')
    print(f'ball+0x158 (out)= {hex(ball+0x158)}')
    print(f'distinct kernel state ptrs: {[hex(s) for s in info["states"]]}')
    print(f'distinct params ptrs: {[hex(p) for p in info["params"]]}')
    print(f'drag_fn calls: {info["n"]}  ladder calls: {info["ladder"]}')

    # which buffer is the working state? dump around it
    for s in info['states']:
        print(f'\nworking state {hex(s)}:')
        print(f'  is ball+0x30: {s == ball+0x30}   is ball+0x158: {s == ball+0x158}')
        b = bytes(core.safe_read(s, 0x128))
        ldr = struct.unpack_from('<6f', b, 0x74)
        print(f'  ladder now: {[round(v,3) for v in ldr]} mode='
              f'{struct.unpack_from("<i", b, 0x8c)[0]}')


if __name__ == '__main__':
    main()
