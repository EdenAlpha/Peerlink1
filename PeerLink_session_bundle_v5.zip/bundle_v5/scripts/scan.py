#!/usr/bin/env python3
"""Vectorized code reference scanner with correct vaddr->offset mapping.

The libUE4.so LOAD segments are NOT identity-mapped:
  seg1 (.rodata):     vaddr 0x0        off 0x0        (identity)
  seg2 (.text):       vaddr 0x28293c0  off 0x28253c0  (delta -0x4000)
  seg3 (.data.rel.ro) vaddr 0x8b75140  off 0x8b6d140  (delta -0x8000)
  seg4 (.data/.bss)   vaddr 0x9906cc0  off 0x98facc0  (delta -0xC000)
"""
import struct
import sys

import numpy as np

LIB = '/home/z/my-project/apk_lab/libUE4.so'

SEGS = [
    (0x0, 0x0, 0x28253b0),
    (0x28293c0, 0x28253c0, 0x6347d80),
    (0x8b75140, 0x8b6d140, 0xd8db80),
    (0x9906cc0, 0x98facc0, 0xca61c8),
]


def v2o(vaddr):
    for va, off, sz in SEGS:
        if va <= vaddr < va + sz:
            return off + (vaddr - va)
    return None


def read(vaddr, n):
    o = v2o(vaddr)
    with open(LIB, 'rb') as f:
        f.seek(o)
        return f.read(n)


def u32(vaddr):
    return struct.unpack('<I', read(vaddr, 4))[0]


# ---------------------------------------- ADRP page-reference scan (text)
def scan_page(page, text_lo=0x28293c0, text_hi=0x8b6d140):
    """All ADRPs in .text resolving to `page` (vaddr)."""
    blob = read(text_lo, text_hi - text_lo)
    text = np.frombuffer(blob, dtype='<u4').astype(np.uint64)
    pcs = np.arange(text_lo, text_hi, 4, dtype=np.uint64)
    is_adrp = (text & np.uint64(0x9F000000)) == np.uint64(0x90000000)
    imm = ((text >> np.uint64(29)) & np.uint64(3)) | \
          (((text >> np.uint64(5)) & np.uint64(0x7FFFF)) << np.uint64(2))
    imm = np.where(imm & np.uint64(0x100000), imm - np.uint64(0x200000), imm)
    pages = (pcs + (imm << np.uint64(12))) & np.uint64(0xFFFFFFFFFFFFF000)
    sel = is_adrp & (pages == np.uint64(page))
    return pcs[sel].tolist()


# ---------------------------------------- BL caller scan
def find_bl(target, text_lo=0x28293c0, text_hi=0x8b6d140):
    """All pc in .text with BL/B decoding to target."""
    blob = read(text_lo, text_hi - text_lo)
    text = np.frombuffer(blob, dtype='<u4').astype(np.uint64)
    pcs = np.arange(text_lo, text_hi, 4, dtype=np.uint64)
    is_bl = ((text >> np.uint64(26)) == np.uint64(0x25)) | \
            ((text >> np.uint64(26)) == np.uint64(0x05))
    off = text & np.uint64(0x3FFFFFF)
    off = np.where(off & np.uint64(0x2000000), off - np.uint64(0x4000000), off)
    tgt = pcs + (off << np.uint64(2))
    sel = is_bl & (tgt == np.uint64(target))
    return pcs[sel].tolist()


if __name__ == '__main__':
    mode = sys.argv[1]
    if mode == 'page':
        page = int(sys.argv[2], 16)
        hits = scan_page(page)
        print(f'ADRP refs to page {page:#x}: {len(hits)}')
        for pc in hits:
            print('  %#x' % pc)
    elif mode == 'bl':
        target = int(sys.argv[2], 16)
        hits = find_bl(target)
        print(f'BL/B refs to {target:#x}: {len(hits)}')
        for pc in hits:
            print('  %#x' % pc)
