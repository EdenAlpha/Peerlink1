#!/usr/bin/env python3
"""MILESTONE 6: run the REAL MatchMain state machine (0x69917d8) headlessly,
state 1 (PLAYING), so 0x69919e0 — the playing-state update — executes through
Konami's own code with the real ball-module path and the team orchestrator.

Architecture (all addresses = original Konami code, SHA-pinned build):

    0x69917d8(match)                  MatchMain state machine
      x20 = *(0xa4cff08)              singleton A (App context)
      x22 = *(0xa4d0228)              singleton B ([B+0x30]==4 → ready)
      w21 = vtobj->vt[0x10]()         vtobj = *(0x9959fa0)
      state [match+0x139] = 1  →  guards  →  0x69919e0(match)
                                     │
                                     ├ 0x68b0408(match+0x265B0)  input collect (virtual ctrl)
                                     ├ [match+0x2DB] → 0x6a059b0([match+0x2F8])  ball module mgr
                                     ├ 0x66f1770(*(0xa409b10), 1/27)   dt install
                                     └ 0x6992220(match)  team orchestrator (2 sides)

Fabrications (the "plugs"):
  - match object (0x40000 zeros) + inner core obj with ball module manager
  - singletons A/B, dt manager, vtable-obj with controllable virtuals
  - guard array *(0xa409788) with [9] = guard obj returning true

Validations:
  M6a  SM dispatch: state 1 reached, 0x69919e0 entered (watcher)
  M6b  playing update completes without fault; kernel calls observed via the
       real path (ball module manager lanes)
  M6c  dt installed: dt_mgr[0x32c] == 1/27
  M6d  team orchestrator 0x6992220 executed (watcher), fault-tolerant
  M6e  execution coverage: basic-block trace of Konami functions run
"""
import json
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from uc_loader2 import EFootballCoreV2
from ball_object_run import BallWorld
from unicorn import *
from unicorn.arm64_const import *

OUT = '/home/z/my-project/apk_lab/analysis/matchmain_run.json'

# ---- original Konami addresses -------------------------------------------------
A_SM = 0x69917d8            # MatchMain state machine
A_PLAYING = 0x69919e0        # playing-state update
A_TEAM_ORCH = 0x6992220      # team orchestrator (tail-called by playing)
A_BALL_UPDATE = 0x6a059b0    # match core -> ball module manager tick
A_INPUT_COLLECT = 0x68b0408  # match+0x265B0 -> virtual controller
A_DT_MGR_GET = 0x66f0238     # *(0xa409b10)
A_DT_INSTALL = 0x66f1770     # (dtmgr, dt)
A_TS = 0x6813eb8             # -> 27.0

# singleton globals in .bss
G_A = 0xa4cff08              # 0x813fe80
G_B = 0xa4d0228              # 0x81604f4
G_VTOBJ = 0x9959fa0          # 0x6836474
G_DT = 0xa409b10             # 0x66f0238
G_GUARD = 0xa409788          # 0x66cf4cc  (array of objects, [9] used)
G_G2 = 0xa40ff48             # 0x6988524  (optional bit-guard, NULL = skip)

MATCH_SIZE = 0x40000
OFF_STATE = 0x139
OFF_2DB = 0x2db
OFF_2F8 = 0x2f8
OFF_265B0 = 0x265B0
OFF_26840 = 0x26840
EXEC_BASE = 0xA4000000000            # RWX arena for tiny guest stubs


STUB_INPUT_COLLECTOR = True


class MatchMainWorld:
    """Harness for the MatchMain state machine climb."""

    def __init__(self, verbose=True):
        # BallWorld builds the full M2 fabrication set (GOT hijacks, G global,
        # component manager with ball.o params, module registry, the five
        # engine-plumbing neutralizations). Reuse it verbatim.
        bw = BallWorld(verbose=verbose)
        self.core = bw.core
        self.bw = bw
        self.events = []          # (name, data) ordered event log
        self.blocks = set()       # basic-block coverage (text range)
        self._build()

    # ---------------------------------------------------------------- fabrication
    def _build(self):
        core = self.core

        # -- match object ------------------------------------------------------
        self.match = core.alloc(MATCH_SIZE, b'\0' * MATCH_SIZE, name='match')

        # -- singleton A (App context; [A+0] is a byte read by 0x8142424) ------
        self.objA = core.alloc(0x2000, b'\0' * 0x2000, name='singletonA')
        core.write_u64(core.base + G_A, self.objA)

        # -- singleton B: 0x8160680(B) -> ([B+0x30]==4). set 4 so state-0 gate ok
        self.objB = core.alloc(0x2000, b'\0' * 0x2000, name='singletonB')
        core.write_u32(self.objB + 0x30, 4)
        core.write_u64(core.base + G_B, self.objB)

        # -- vtable-obj *(0x9959fa0) with fabricated vtable --------------------
        # virtuals used: +0x10 (w21 provider), +0x288 (state2 x1=match+0x308),
        # +0x2a0 (state compare), +0x290, +0x1c8. w21 must be 0 (no pending end).
        self.vt = core.alloc(0x400, b'\0' * 0x400, name='vtobj_vtable')
        self.vtobj = core.alloc(0x800, b'\0' * 0x800, name='vtobj')
        core.write_u64(self.vtobj, self.vt)
        for off in (0x10, 0x288, 0x2a0, 0x290, 0x1c8):
            core.write_u64(self.vt + off, core.base + A_SM + 0)  # placeholder
        # install explicit return-value stubs via small code pages
        self._vt_stub(0x10, 0)      # w21 = 0  (no state-change event)
        self._vt_stub(0x288, 1)     # ok
        self._vt_stub(0x2a0, 0)
        self._vt_stub(0x290, 1)
        self._vt_stub(0x1c8, 0)
        core.write_u64(core.base + G_VTOBJ, self.vtobj)

        # -- dt manager *(0xa409b10) -------------------------------------------
        self.dtmgr = core.alloc(0x1000, b'\0' * 0x1000, name='dtmgr')
        core.write_u64(core.base + G_DT, self.dtmgr)

        # -- guard array *(0xa409788): [9] must be obj whose vt[0x48]() -> 1 ---
        self.garr = core.alloc(16 * 8, b'\0' * (16 * 8), name='guard_array')
        self.gobj = core.alloc(0x200, b'\0' * 0x200, name='guard_obj9')
        self.gvt = core.alloc(0x100, b'\0' * 0x100, name='guard_vt9')
        core.write_u64(self.gobj, self.gvt)
        self._ret1 = self._emit_ret1('ret1_guard')
        core.write_u64(self.gvt + 0x48, self._ret1)
        core.write_u64(self.garr + 9 * 8, self.gobj)
        core.write_u64(core.base + G_GUARD, self.garr)

        # -- optional bit-guard *(0xa40ff48): leave NULL (cbz skips it) --------
        # -- ball module manager inside inner core object ----------------------
        # (reuse the M4-verified construction: manager ctor + module A/B)
        self.mgr = core.alloc(0x200, b'\0' * 0x200, name='ball_mgr')
        r = core.call(0x6a352c4, x0=self.mgr)
        assert not r['error'], r
        # module A/B (w1=0/1) via the M2-verified construction path
        self.modA = self.bw.construct()
        self.modB = self._make_ball_module(1)
        core.write_u64(self.mgr + 0x38, self.modA)
        core.write_u64(self.mgr + 0x40, self.modB)
        # inner core object: [core+0x3C98] = mgr
        self.inner_core = core.alloc(0x8000, b'\0' * 0x8000, name='inner_core')
        core.write_u64(self.inner_core + 0x3C98, self.mgr)
        # match links
        core.write_u64(self.match + OFF_2F8, self.inner_core)
        core.write_u8(self.match + OFF_2DB, 1)      # ball path enabled
        core.write_u8(self.match + OFF_STATE, 1)    # PLAYING

        # substep globals for the ball chain (N=3 like M1)
        core.set_substep_global(3)
        core.write_u32(core.base + 0x9959f98, 3)

        # -- INPUT PLUGS (data-only, M6): the controller-hub (match+0x265B0)
        # and team-side region (match+0x26B60) are lazy-getter objects:
        #   valid byte [X+8]=1 skips the vtable init path; cached ptr
        #   [X+0x40]/[X+0x48]=NULL -> create path reads source [X+0x30]=NULL
        #   -> the game's own code stores NULL and returns it cleanly.
        # M7 replaces the NULL sources with the real input bank (.trep feed).
        for region in (OFF_265B0, 0x26B60):
            core.write_u8(self.match + region + 8, 1)
        print('[M6] data plugs: hub/team regions valid, sources NULL '
              '(M7: real input bank)')

    def _make_ball_module(self, lane):
        """Module via the M2 construction chain (bw.construct with w1 swap)."""
        core = self.core
        mod = core.alloc(0x14B8, b'\0' * 0x14B8, name=f'ball_module_{lane}')
        r = core.call(0x6e92768, x0=mod, w1=lane)
        assert not r['error'], r
        holder = core.alloc(0x8000, b'\0' * 0x8000, name=f'holder{lane}')
        core.write_u8(mod + 0x360, 1)
        core.write_u64(mod + 0x3A0, holder)
        r = core.call(0x6e91da8, x0=mod, w1=lane)
        assert not r['error'], r
        return mod

    # ---------------------------------------------------------------- stub emit
    def _exec_alloc(self, code, name):
        """Emit tiny guest code into the RWX stub arena."""
        if not hasattr(self, '_exec_next'):
            self.core.uc.mem_map(EXEC_BASE, 0x100000, UC_PROT_ALL)
            self._exec_next = EXEC_BASE
        a = self._exec_next
        self._exec_next = (a + max(len(code), 16) + 0xFF) & ~0xFF
        assert self._exec_next < EXEC_BASE + 0x100000
        self.core.uc.mem_write(a, code)
        return a

    def _emit_ret1(self, name):
        """Tiny guest code: mov w0,#1; ret"""
        return self._exec_alloc(struct.pack('<II', 0x52800020, 0xD65F03C0), name)

    def _vt_stub(self, off, retval):
        """Install a mov w0,#retval; ret stub at vtable slot `off`."""
        core = self.core
        page = self._exec_alloc(
            struct.pack('<II', 0x52800000 | ((retval & 0xFFFF) << 5), 0xD65F03C0),
            f'vt_{off:#x}_{retval}')
        core.write_u64(self.vt + off, page)
        return page

    # ---------------------------------------------------------------- tracing
    def install_tracers(self):
        core = self.core

        def ev(name):
            def cb(uc, c):
                self.events.append((name, uc.reg_read(UC_ARM64_REG_X0)))
            return cb

        self.w_play = core.watch(A_PLAYING, ev('playing_enter'), 'playing')
        self.w_team = core.watch(A_TEAM_ORCH, ev('team_orch_enter'), 'team')
        self.w_ball = core.watch(A_BALL_UPDATE, ev('ball_update_enter'), 'ball')
        self.w_in = core.watch(A_INPUT_COLLECT, ev('input_collect_enter'), 'input')
        self.w_sm = core.watch(A_SM, ev('sm_enter'), 'sm')

        kernel_calls = []

        def kcb(uc, c):
            x2 = uc.reg_read(UC_ARM64_REG_X2)
            w4 = uc.reg_read(UC_ARM64_REG_X4) & 1
            kernel_calls.append((x2, w4))
        self.kernel_calls = kernel_calls
        self.w_kernel = core.watch(0x6ea0958, kcb, 'kernel')

        # basic-block coverage over the whole text
        self.core.uc.hook_add(UC_HOOK_BLOCK, self._block_cb)

    def _block_cb(self, uc, addr, size, ud):
        self.blocks.add(addr - self.core.base)

    # ---------------------------------------------------------------- run
    def run_frame(self, state=1, timeout_s=120):
        core = self.core
        core.write_u8(self.match + OFF_STATE, state)
        # clear the playing scratch the way the game does (idempotent)
        r = core.call(A_SM, x0=self.match, timeout_s=timeout_s,
                      max_insns=400_000_000)
        return r


def main():
    world = MatchMainWorld(verbose=True)
    core = world.core
    res = {}

    print('=== M6: MatchMain SM — state 1 (PLAYING) ===')
    world.install_tracers()
    r = world.run_frame(state=1)
    print('[SM call]', {'error': r['error'], 'pc': hex(r['pc'])})
    state_after = core.safe_read(world.match + OFF_STATE, 1)[0]
    print(f'state byte after: {state_after}')

    # what executed?
    names = [e[0] for e in world.events]
    res['M6a'] = {
        'sm_error': r['error'],
        'events': [e[0] for e in world.events],
        'playing_entered': 'playing_enter' in names,
        'team_orch_entered': 'team_orch_entered' in names,
        'ball_update_entered': 'ball_update_entered' in names,
        'input_collect_entered': 'input_collect_entered' in names,
        'state_after': state_after,
        'kernel_calls': len(world.kernel_calls),
    }
    print('[M6a]', res['M6a'])

    # dt installed?
    dt = core.read_f32(world.dtmgr + 0x32c)
    inv = core.read_f32(world.dtmgr + 0x330)
    res['M6c'] = {'dt': dt, 'inv_dt': inv, 'pass': abs(dt - 1 / 27.0) < 1e-9}
    print('[M6c]', res['M6c'])

    # faults?
    faults = [l for l in core._log if 'FAULT' in l or 'INVALID' in l
              or 'unhandled import' in l]
    res['M6b'] = {'faults': faults[:20], 'n_faults': len(faults)}
    print('[M6b] faults:', len(faults))
    for f in faults[:10]:
        print('   ', f)

    # coverage stats
    res['M6e'] = {'blocks_executed': len(world.blocks)}
    print('[M6e] blocks executed:', len(world.blocks))

    json.dump(res, open(OUT, 'w'), indent=1, default=str)
    print('JSON ->', OUT)
    return world, res


if __name__ == '__main__':
    main()
