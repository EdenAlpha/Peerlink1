#!/usr/bin/env python3
"""M5.4: correlate .trep float lanes with .rep player/ball per frame.

.rep: 44,400 hdr + 1,200 x 10,976; 808 global + 31x328 entities;
      player XYZ at entity+0xB6 (i16/256); ball slots at g+0x2D4/+0x2F0/+0x30C.
.trep: 12 hdr + 1,200 x 844 (16B sample hdr + 828 payload).

Match: for each varying .trep f-lane, find the .rep series (players/ball)
with best per-frame correlation.
"""
import struct
import numpy as np

BASE = '/home/z/my-project/apk_lab/cpk/dt270_out/common/match'
HDR, REC, GLOB, ENT, NENT = 44400, 10976, 808, 328, 31

d = open(f'{BASE}/tutorial_replay/tutorial_replay_shooting_02.rep', 'rb').read()
N = (len(d) - HDR) // REC
assert N == 1200

players = np.zeros((N, NENT, 3))
for i in range(N):
    base = HDR + i * REC + GLOB
    for e in range(NENT):
        eb = base + e * ENT
        x, y, z = struct.unpack_from('<hhh', d, eb + 0xB6)
        players[i, e] = (x / 256, y / 256, z / 256)

balls = np.zeros((N, 3, 3))  # frame, slot, xyz
for i in range(N):
    base = HDR + i * REC
    for s, so in enumerate((0x2D4, 0x2F0, 0x30C)):
        bx, by, bz = struct.unpack_from('<hhh', d, base + so + 0x10)
        balls[i, s] = (bx / 256, by / 256, bz / 256)

# active ball = slot with movement
act = np.zeros((N, 3))
for i in range(N):
    s = int(np.argmax(np.abs(balls[i]).sum(axis=1)))
    act[i] = balls[i, s]

t = open(f'{BASE}/tutorial_replay/tutorial_replay_shooting_02.trep', 'rb').read()
samples = np.frombuffer(t[12:], dtype=np.uint8).reshape(1200, 844).copy()
pay_f = samples[:, 16:].view('<f4').reshape(1200, 207).copy()

# candidate .rep series: 31 players x 3 axes + ball 3 axes
series = {}
for e in range(NENT):
    for ax, nm in enumerate('xyz'):
        series[f'p{e:02d}.{nm}'] = players[:, e, ax]
for ax, nm in enumerate('xyz'):
    series[f'ball.{nm}'] = act[:, ax]

print('matching varying .trep lanes to .rep series (r > 0.99):')
matches = {}
for i in range(207):
    lane = pay_f[:, i]
    u = np.unique(lane)
    if len(u) < 20:
        continue
    for nm, s in series.items():
        if np.std(s) < 1e-6:
            continue
        # align: allow constant offset + exact scale 1
        dl = lane - lane.mean()
        ds = s - s.mean()
        denom = np.sqrt((dl * dl).sum() * (ds * ds).sum())
        if denom < 1e-9:
            continue
        r = float((dl * ds).sum() / denom)
        if abs(r) > 0.995:
            off = float(np.median(lane - s)) if r > 0 else float(np.median(lane + s))
            matches[i] = (nm, r, off)
            print(f'  f-lane {i:3d} (byte {16+4*i:4d}) ~ {nm:9s} r={r:+.5f} offset={off:+.4f}')

# unmatched varying lanes
print('\nunmatched varying lanes (>20 uniq):')
for i in range(207):
    if i in matches:
        continue
    lane = pay_f[:, i]
    if len(np.unique(lane)) >= 20:
        print(f'  f-lane {i:3d} (byte {16+4*i:4d}): {len(np.unique(lane))} uniq, '
              f'[{lane.min():.3f}, {lane.max():.3f}]')

np.save('/home/z/my-project/apk_lab/analysis/shooting02_players.npy', players)
np.save('/home/z/my-project/apk_lab/analysis/shooting02_ball.npy', act)
print('\nsaved players/ball tracks -> analysis/*.npy')
