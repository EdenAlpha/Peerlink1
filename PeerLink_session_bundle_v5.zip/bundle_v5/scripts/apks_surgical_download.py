#!/usr/bin/env python3
"""Surgical ranged downloader for the eFootball 11.0.1 .apks bundle (STORE zip).

The 862,826,266-byte .apks is a ZIP with STORE method, so every member is a
byte-exact slice of the remote file. We fetch the central directory, list all
members, then download only the slices we need (arm64 split, base apk, etc.).

Outputs:
  /home/z/my-project/apk_lab/apks/  — downloaded slices, reassembled as files
"""
import os
import re
import struct
import subprocess
import sys

URL_FILE = '/home/z/my-project/scripts/r2_url.txt'
UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36'
OUT = '/home/z/my-project/apk_lab/apks'
TOTAL = None


def url():
    return open(URL_FILE).read().strip()


def fetch_range(start, length, out_path=None, tries=5):
    """GET bytes [start, start+length) via curl; returns bytes or writes to file."""
    end = start + length - 1
    for t in range(tries):
        cmd = ['curl', '-s', '-m', '300', '-A', UA, '-L',
               '-r', f'{start}-{end}', url()]
        if out_path:
            cmd += ['-o', out_path]
            r = subprocess.run(cmd, capture_output=True)
            if r.returncode == 0 and os.path.exists(out_path) and os.path.getsize(out_path) == length:
                return True
            # cleanup partial
            if os.path.exists(out_path):
                os.remove(out_path)
        else:
            r = subprocess.run(cmd, capture_output=True)
            if r.returncode == 0 and len(r.stdout) == length:
                return r.stdout
        print(f'  retry {t+1} for range {start}-{end}', file=sys.stderr)
    raise RuntimeError(f'range fetch failed: {start}+{length}')


def get_total():
    global TOTAL
    r = subprocess.run(['curl', '-s', '-m', '60', '-A', UA, '-L', '-r', '0-0',
                        url(), '-o', '/dev/null', '-D', '-'], capture_output=True, text=True)
    m = re.search(r'content-range:.*?/(\d+)', r.stdout, re.I)
    TOTAL = int(m.group(1))
    return TOTAL


def parse_central_dir():
    """Fetch EOCD + central directory from the tail."""
    tail_len = 4 * 1024 * 1024  # 4MB tail is plenty for the CD
    tail = fetch_range(TOTAL - tail_len, tail_len)
    # find EOCD (PK\x05\x06) scanning backwards
    eocd = None
    for i in range(len(tail) - 22, -1, -1):
        if tail[i:i + 4] == b'PK\x05\x06':
            eocd = i
            break
    if eocd is None:
        raise RuntimeError('EOCD not found')
    (cd_size, cd_off) = struct.unpack_from('<II', tail, eocd + 12)
    (n_entries,) = struct.unpack_from('<H', tail, eocd + 10)
    print(f'EOCD: {n_entries} entries, CD size {cd_size:,} at {cd_off:#x}')
    # CD may be fully inside tail
    cd_rel = eocd - cd_size
    if cd_rel >= 0:
        cd = tail[cd_rel:eocd]
    else:
        # need an extra fetch for the front part of the CD
        front = fetch_range(cd_off, cd_size - (len(tail) - eocd))
        cd = front + tail[:eocd]
    entries = []
    p = 0
    while p + 46 <= len(cd) and cd[p:p + 4] == b'PK\x01\x02':
        (csize, usize) = struct.unpack_from('<II', cd, p + 20)
        (name_len, extra_len, comm_len) = struct.unpack_from('<HHH', cd, p + 28)
        lho = struct.unpack_from('<I', cd, p + 42)[0]
        name = cd[p + 46:p + 46 + name_len].decode('utf-8', 'replace')
        # zip64 extra?
        if extra_len:
            e = cd[p + 46 + name_len:p + 46 + name_len + extra_len]
            q = 0
            while q + 4 <= len(e):
                hid, hsz = struct.unpack_from('<HH', e, q)
                if hid == 0x0001:
                    if usize == 0xFFFFFFFF:
                        usize = struct.unpack_from('<Q', e, q + 4)[0]
                    if csize == 0xFFFFFFFF:
                        csize = struct.unpack_from('<Q', e, q + 12)[0]
                    if lho == 0xFFFFFFFF:
                        lho = struct.unpack_from('<Q', e, q + 20)[0]
                q += 4 + hsz
        entries.append(dict(name=name, csize=csize, usize=usize, lho=lho, method=None))
        p += 46 + name_len + extra_len + comm_len
    print(f'parsed {len(entries)} central-dir entries')
    return entries


def get_local_header(entry):
    lh = fetch_range(entry['lho'], 30)
    assert lh[:4] == b'PK\x03\x04'
    (name_len, extra_len) = struct.unpack_from('<HH', lh, 26)
    method = struct.unpack_from('<H', lh, 8)[0]
    csize = struct.unpack_from('<I', lh, 18)[0]
    data_off = entry['lho'] + 30 + name_len + extra_len
    entry['method'] = method
    if csize and csize != 0xFFFFFFFF:
        entry['csize'] = csize
    return data_off


def download_member(entry, dest_name=None, chunk=64 * 1024 * 1024):
    data_off = get_local_header(entry)
    n = entry['csize']
    name = dest_name or entry['name'].replace('/', '_')
    out_path = os.path.join(OUT, name)
    os.makedirs(OUT, exist_ok=True)
    print(f"  downloading {entry['name']} ({n:,} bytes, method={entry['method']})")
    with open(out_path, 'wb') as f:
        pos = 0
        while pos < n:
            ln = min(chunk, n - pos)
            part = fetch_range(data_off + pos, ln)
            f.write(part)
            pos += ln
            print(f'    {pos:,}/{n:,} ({100*pos/n:.0f}%)', flush=True)
    return out_path


if __name__ == '__main__':
    total = get_total()
    print(f'total remote size: {total:,}')
    entries = parse_central_dir()
    os.makedirs(OUT, exist_ok=True)
    for e in entries:
        print(f"  {e['name']}  csize={e['csize']:,}")
    import json
    json.dump(entries, open(os.path.join(OUT, 'apks_manifest.json'), 'w'), indent=1)
