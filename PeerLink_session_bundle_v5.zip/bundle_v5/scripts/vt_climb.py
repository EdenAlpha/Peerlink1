#!/usr/bin/env python3
"""M4 continued: vtable dump + ancestry climb on the BL+B graph.

1. Dump complete vtables around 0x978d388 and 0x98d0500 (driver family)
   and 0x979cac8 (ball object family).
2. Find code referencing each vtable base (constructors / users).
3. Full upward ancestry on fgraph2 (BL + B tail calls) from ball update,
   player replay writer, MatchCommand, RP_RAND_SEED — intersection = tick.
"""
import json
import numpy as np
from collections import deque

AN = '/home/z/my-project/apk_lab/analysis'

fg = np.load(f'{AN}/fgraph2.npz')
ent = np.sort(fg['entries'].astype(np.int64))
src = fg['src'].astype(np.int64)
dst = fg['dst'].astype(np.int64)
order = np.argsort(dst)
d_sorted, s_sorted = dst[order], src[order]
forder = np.argsort(src)
f_sorted, t_sorted = src[forder], dst[forder]


def callers_of(f):
    i, j = np.searchsorted(d_sorted, f, 'left'), np.searchsorted(d_sorted, f, 'right')
    return np.unique(s_sorted[i:j]).tolist()


def callees_of(f):
    i, j = np.searchsorted(f_sorted, f, 'left'), np.searchsorted(f_sorted, f, 'right')
    return np.unique(t_sorted[i:j]).tolist()


# ---------- 1. vtable dumps ----------
pr = np.load(f'{AN}/packed_relocs.npz')
roff, radd = pr['offset'].astype(np.int64), pr['addend'].astype(np.int64)
oorder = np.argsort(roff)
ro_s, ra_s = roff[oorder], radd[oorder]


def vtable_dump(base, length=0x100):
    i, j = np.searchsorted(ro_s, base, 'left'), np.searchsorted(ro_s, base + length, 'right')
    slots = [(o - base, a) for o, a in zip(ro_s[i:j].tolist(), ra_s[i:j].tolist())]
    return slots


VT_BASES = [0x978d388, 0x98d0500, 0x979cac8]
ad = np.load(f'{AN}/adrp_map.npz')
rt = ad['ref_target'].astype(np.int64)
rs = ad['ref_site'].astype(np.int64)
aorder = np.argsort(rt)
rt_s, rs_s = rt[aorder], rs[aorder]


def refs_to(t):
    i, j = np.searchsorted(rt_s, t, 'left'), np.searchsorted(rt_s, t, 'right')
    return rs_s[i:j].tolist()


def func_of(site):
    i = np.searchsorted(ent, site, 'right') - 1
    return int(ent[i]) if i >= 0 else None


print('=== VTABLES ===')
for vb in VT_BASES:
    # true base: walk back to slot 0 (aligned, previous slots contiguous)
    slots = vtable_dump(vb - 0x40, 0x180)
    print(f'\n vtable near {vb:#x} (window {vb-0x40:#x}..+0x140):')
    for off, a in slots:
        rel = (vb - 0x40) + off
        print(f'   slot @ {rel:#x} (+{off - 0x40:+#x} vs {vb:#x}): {a:#x}')
    # who references the vtable region?
    i, j = np.searchsorted(rt_s, vb - 0x40, 'left'), np.searchsorted(rt_s, vb + 0x140, 'right')
    refsites = rs_s[i:j].tolist()
    reffuncs = sorted(set(func_of(x) for x in refsites if func_of(x)))
    print(f'   referenced by funcs: {[hex(x) for x in reffuncs[:20]]}')

# ---------- 2. ancestry on fgraph2 ----------
print('\n=== ANCESTRY (BL+B graph) ===')


def ancestors(seed, max_funcs=100000):
    seen = set()
    frontier = [seed]
    levels = []
    while frontier and len(seen) < max_funcs:
        seen.update(frontier)
        levels.append(frontier)
        nxt = set()
        for f in frontier:
            nxt.update(callers_of(f))
        nxt -= seen
        frontier = sorted(nxt)
    return seen, levels


SEEDS = {
    'ball': [0x6e938a0],
    'player': [0x728d7e0, 0x6f45bc4, 0x6f45e2c],
    'command': [0x7bff91c, 0x7ceafc4],
}
anc = {}
for name, seeds in SEEDS.items():
    u = set()
    for s in seeds:
        a, lv = ancestors(s)
        u |= a
        print(f'  {name} seed {s:#x}: {len(a)} ancestors over {len(lv)} levels; top: {[hex(f) for f in lv[-1][:12]]}')
    anc[name] = u
    print(f'  => {name} union: {len(u)}')

inter_bp = anc['ball'] & anc['player']
inter_all = anc['ball'] & anc['player'] & anc['command']
print(f'\nball ∩ player: {len(inter_bp)}')
print(f'all three:     {len(inter_all)}')


def minimal(s, cap=40):
    out = []
    for f in sorted(s):
        cs = callers_of(f)
        if not any(c in s for c in cs):
            out.append(f)
        if len(out) >= cap:
            break
    return out


if inter_bp:
    print('minimal ball∩player:', [hex(m) for m in minimal(inter_bp)])
if inter_all:
    print('minimal all:', [hex(m) for m in minimal(inter_all)])

# save full ancestries for later steps
json.dump({k: [hex(x) for x in sorted(v)] for k, v in anc.items()},
          open(f'{AN}/ancestries.json', 'w'))
print('\nJSON ->', f'{AN}/ancestries.json')
