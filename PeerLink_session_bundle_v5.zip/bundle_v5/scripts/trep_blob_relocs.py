#!/usr/bin/env python3
"""M5.1c: find relocs whose addend lands in the replay-string blob ->
the filename pointer table -> code that walks it.
"""
import numpy as np
import json

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'

data = open(SO, 'rb').read()
strs = json.load(open(f'{AN}/replay_strings.json'))

# full blob range: collect all string vaddrs
vas = sorted({int(va, 16) for lst in strs.values() for va, _ in lst})
lo, hi = min(vas), max(vas) + 256
print(f'string blob: {lo:#x} .. {hi:#x}, {len(vas)} strings')

z = np.load(f'{AN}/packed_relocs.npz', allow_pickle=True)
off, sym, rtype, addend = z['offset'], z['sym'], z['rtype'], z['addend']

# relocs whose addend lands in blob (RELATIVE data pointers)
mask = (addend >= lo) & (addend < hi)
print(f'relocs with addend in blob: {mask.sum()}')
hits_off = off[mask]
hits_add = addend[mask]
hits_rt = rtype[mask]

# cluster the reloc offsets (the pointer table location(s))
order = np.argsort(hits_off)
ho, ha, hr = hits_off[order], hits_add[order], hits_rt[order]
print(f'reloc-offset range: {ho.min():#x} .. {ho.max():#x}')
print(f'reloc types: {np.unique(hr, return_counts=True)}')

# how many addends point at exact string starts?
vaset = set(vas)
exact = [(int(o), int(a)) for o, a in zip(ho, ha) if int(a) in vaset]
print(f'addends == exact string starts: {len(exact)}')
for o, a in exact[:40]:
    off_in_blob = a - lo
    print(f'   reloc_off {o:#x} -> str {a:#x}')

json.dump({'blob': [hex(lo), hex(hi)],
           'relocs': [[hex(int(o)), hex(int(a)), int(r)] for o, a, r in zip(ho, ha, hr)]},
          open(f'{AN}/replay_blob_relocs.json', 'w'), indent=1)
print('JSON -> replay_blob_relocs.json')
