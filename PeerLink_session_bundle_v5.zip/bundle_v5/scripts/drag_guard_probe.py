#!/usr/bin/env python3
"""Watch the kernel's drag fn (0x6ea1938) and the speed-class ladder
(0x6ea555c) during (a) a pure drop from 3 m (no crash) and (b) a 25.5 m/s
horizontal flight (ladder recursion crash). Reveals the guard difference and
the state's ladder fields at call time."""
import struct
import sys

sys.path.insert(0, '/home/z/my-project/scripts')
from ball_object_run import BallWorld, state_vec

A_DRAG_FN = 0x6ea1938
A_LADDER = 0x6ea555c


def run_case(world, pos, vel, label, n=8):
    core = world.core
    events = []

    def drag_cb(uc, core_):
        x1 = uc.reg_read(10)   # X1 = state
        s0 = struct.unpack('<f', struct.pack('<I', uc.reg_read(0) & 0xffffffff))[0]
        b = bytes(core_.safe_read(x1, 0x128))
        ldr = struct.unpack_from('<6f', b, 0x74)
        mode = struct.unpack_from('<i', b, 0x8c)[0]
        events.append(('drag_fn', s0, ldr, mode))

    def ladder_cb(uc, core_):
        x0 = uc.reg_read(0)    # X0 = state
        s0 = struct.unpack('<f', struct.pack('<I', uc.reg_read(0) & 0xffffffff))[0]
        events.append(('ladder', s0, 0, 0))

    w1 = core.watch(A_DRAG_FN, drag_cb, name='dragfn')
    w2 = core.watch(A_LADDER, ladder_cb, name='ladder')
    world.set_N(2)
    world.set_state(pos, vel=vel, phys=1, sub=6)
    world.reset_kernel_ctx()
    err = None
    try:
        for _ in range(n):
            world.tick_feedback()
    except Exception as e:
        err = str(e)[:120]
    core.unwatch(w1)
    core.unwatch(w2)
    print(f'--- {label}: err={err}')
    print(f'    events: {len(events)}')
    for e in events[:10]:
        kind, s0, ldr, mode = e
        if kind == 'drag_fn':
            print(f'    drag_fn(dt={s0:.5f}) state ladder={["%.3f" % v for v in ldr]} mode={mode}')
        else:
            print(f'    ladder(speed={s0:.4f})')
    if len(events) > 10:
        print(f'    ... {len(events)-10} more')


def main():
    world = BallWorld(verbose=False)
    world.construct()
    run_case(world, (0, 3.0, 0), (0, 0, 0), 'pure drop from 3m (NO crash)')
    run_case(world, (0, 3.0, 0), (25.5, 0, 0), '25.5 m/s horizontal (CRASH)')
    run_case(world, (0, 3.0, 0), (0, 0, 25.5), '25.5 m/s pure Z (L1 speed=0)')
    run_case(world, (0, 3.0, 0), (2.0, 0, 0), '2.0 m/s horizontal (below gate)')


if __name__ == '__main__':
    main()
