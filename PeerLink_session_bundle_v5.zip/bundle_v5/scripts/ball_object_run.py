#!/usr/bin/env python3
"""MILESTONE 2 (rebuilt): real ball module object + bit-exact validation.

Reconstructs the Session-B/C achievement that was lost with the container:
- hybrid construction: 0x14B8 ball module via the game's own ctor chain
  (6a35434 semantics: operator new -> 6e92768 base ctor -> 6e91da8 module ctor)
  with ICU-dragging factories neutralized and fabricated singletons
- ball_update_entry (0x6e938a0) drives the FULL native chain:
  gate -> holder -> sub-contexts -> chain_top -> chain_mid -> kernel
- params = ball.o (from constant_match.bin) at component[0x4D]+8
- validations:
    F0  construction sanity (states exist, y0 = ground radius)
    F1  single-tick equivalence vs direct kernel sequence
    F2  30-tick trajectory equivalence, 0/296 byte diffs per tick
    F3  per-tick snapshots + mirrored first-step cadence
    FB  native bounce through the object path (peaks/restitution)
    FC  commit rule: tick(N) commits N-1 substeps

Run:  python scripts/ball_object_run.py [--diag] [--fast]
"""
import json
import os
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from uc_loader2 import EFootballCoreV2
from unicorn.arm64_const import *

OUT = '/home/z/my-project/apk_lab/analysis/ball_object_run.json'

# ---- pinned native addresses (all SHA-verified against 2ac4ff17... build) ----
A_BASE_CTOR = 0x6e92768     # installs vtables incl. +0x498 (via 6e92868)
A_MOD_CTOR = 0x6e91da8      # registry + 6e91de4 + 6e920a0 + 6e920e0
A_BALL_CTOR = 0x6e91de4
A_TICK = 0x6e938a0          # ball_update_entry
A_KERNEL = 0x6ea0958
A_CHAIN_TOP = 0x6ea1e90
A_TICK_PLACEMENT = 0x6a35688  # driven-mode driver (install pos -> tick)
STATE_SZ = 0x128

# engine-plumbing factories that drag ICU/UE string machinery (hybrid skip)
NEUTRALIZE = [
    (0x6e921a0, 'ICU factory +0x498 (6e983c0/6e983cc/6a388fc)'),
    (0x6e92228, 'ICU factory +0x358/+0x3a8 (6e98434/6e98440)'),
    (0x68b24c4, 'in-place registration ctor +0x3f8'),
    (0x6e920e0, 'match-setup reader (68c8c14->68ce104->ICU, abort path)'),
    (0x68d3054, 'camera sub-object wait: pthread_cond_wait spin on render '
                'thread (30s/tick -> 0s; presentation sync, DROP-class)'),
]

RADIUS = 0.1086859330534935


def rd_state(core, addr):
    return bytes(core.safe_read(addr, STATE_SZ))


def state_vec(b, off=0):
    return struct.unpack_from('<3f', b, off)


class BallWorld:
    """Fabricated game-context singletons + real ball module object."""

    def __init__(self, verbose=True):
        self.core = EFootballCoreV2(verbose=verbose)
        core = self.core
        # -- GOT hijacks: C++ allocation operators (UE FMemory overrides) --
        core.hijack_plt('_Znwm', '_Znwm_h')       # operator new(unsigned long)
        core.hijack_plt('_ZdlPv', '_ZdlPv_h')     # operator delete(void*)
        try:
            core.hijack_plt('_Znam', '_Znam_h')   # operator new[]
            core.hijack_plt('_ZdaPv', '_ZdaPv_h')  # operator delete[]
        except KeyError:
            pass
        # -- global context G (kernel env chain + world) --
        self.G = core.fabricate_global(0xa465d88, size=0x40000)
        # -- component manager: params = *(comp[0x4D] + 8) (68d3cb8 deref!) --
        self.comp = core.fabricate_component_manager(0x4D)
        ball_o = open('/home/z/my-project/apk_lab/ball.o', 'rb').read()
        self.params = core.alloc(0x10000, ball_o + b'\0' * (0x10000 - len(ball_o)),
                                  name='params_blob')
        core.write_u64(self.comp + 8, self.params)   # *(C+8) = params object
        # -- substep global: N = *(*(0x98dddc8)) --
        core.set_substep_global(3)
        # -- module registry for 6e91da8 --
        self.registry = core.fabricate_module_registry()
        # -- neutralize engine plumbing --
        for addr, note in NEUTRALIZE:
            core.neutralize(addr, note)

    # ------------------------------------------------------------ construct
    def construct(self):
        core = self.core
        self.ball = core.alloc(0x14B8, b'\0' * 0x14B8, name='ball_module')
        ball = self.ball
        # base ctor: installs vtables, inits state buffers +0x30/+0x158
        r = core.call(A_BASE_CTOR, x0=ball, w1=0)
        self._check(r, 'base ctor 6e92768')
        # holder wiring BEFORE module ctor (6e920a0 reads it via 6a3562c)
        self.holder = core.alloc(0x8000, b'\0' * 0x8000, name='holder')
        core.write_u8(ball + 0x360, 1)          # 68b942c validity byte
        core.write_u64(ball + 0x3A0, self.holder)  # [x+0x48] holder slot
        # module ctor: registry + ball ctor + holder init + match-setup read
        r = core.call(A_MOD_CTOR, x0=ball, w1=0)
        self._check(r, 'module ctor 6e91da8')
        return ball

    def _check(self, r, what):
        if r['error']:
            fatal = [l for l in self.core._log
                     if 'FAULT' in l or 'INVALID' in l or 'GUARD' in l or 'abort' in l]
            raise RuntimeError(f'{what} failed: {r} :: {fatal[-6:]}')

    # ----------------------------------------------------------------- tick
    def set_state(self, pos, vel=(0, 0, 0), rot=(0, 0, 0), state_idx=0,
                  phys=0, sub=0, quat=(1, 0, 0, 0), where=0x30):
        s = bytearray(STATE_SZ)
        struct.pack_into('<3f', s, 0x000, *pos)
        struct.pack_into('<3f', s, 0x00C, *vel)
        struct.pack_into('<3f', s, 0x018, *rot)
        s[0x90] = phys
        s[0x91] = sub
        struct.pack_into('<i', s, 0x094, state_idx)
        struct.pack_into('<4f', s, 0x098, *quat)
        self.core.uc.mem_write(self.ball + where, bytes(s))

    def get_state(self, where=0x158):
        return rd_state(self.core, self.ball + where)

    def tick(self):
        core = self.core
        core.write_u32(self.ball + 0x2D4, 1)   # gate bit0 (one-shot)
        r = core.call(A_TICK, x0=self.ball)
        if r['error']:
            fatal = [l for l in core._log if 'FAULT' in l or 'INVALID' in l]
            raise RuntimeError(f'tick failed: {r} :: {fatal[-6:]}')
        return self.get_state(0x158)

    def tick_feedback(self):
        """Game handshake: tick, then feed output mirror into next input."""
        out = self.tick()
        self.core.uc.mem_write(self.ball + 0x30, out)
        return out

    def set_N(self, n):
        """Both substep globals: N = *(*(0x98dddc8)) (chain_top source) AND
        [0x9959f98] (record capacity / observer last-substep marker)."""
        self.core.set_substep_global(n)
        self.core.write_u32(self.core.base + 0x9959f98, n)

    def reset_kernel_ctx(self):
        """Zero the fabricated G region (kernel persistent ctx lives in the
        G-chain cells — the empirically-found cross-call state)."""
        self.core.uc.mem_write(self.G, b'\0' * 0x40000)


# --------------------------------------------------------------- validation
def capture_kernel_entry(world):
    """Watcher data: (state_ptr, w4, w5, state_bytes) at each kernel entry.
    Returns (caps, watcher) — caller MUST core.unwatch(watcher)."""
    caps = []

    def cb(uc, core):
        x2 = uc.reg_read(UC_ARM64_REG_X2)
        w4 = uc.reg_read(UC_ARM64_REG_X4) & 1
        w5 = uc.reg_read(UC_ARM64_REG_X5) & 1
        caps.append((x2, w4, w5, rd_state(core, x2)))

    w = world.core.watch(A_KERNEL, cb, name='kcap')
    return caps, w


def direct_kernel_seq(world, state_bytes, calls):
    """Run the kernel directly: calls = [(w4, w5), ...]. Returns final bytes."""
    core = world.core
    st = core.alloc(STATE_SZ, state_bytes, name='direct_state')
    for (w4, w5) in calls:
        r = core.call(A_KERNEL, w0=0, w1=1, x2=st, x3=world.params,
                      s0=1.0 / 27.0, w4=w4, w5=w5)
        if r['error']:
            raise RuntimeError(f'direct kernel failed: {r}')
    return rd_state(core, st)


def f0_construction(world):
    b_in = world.get_state(0x30)
    b_out = world.get_state(0x158)
    y_in = state_vec(b_in)[1]
    ok = abs(y_in - RADIUS) < 1e-6
    return {'name': 'F0_construction', 'pass': bool(ok),
            'y_input_state': y_in, 'radius': RADIUS,
            'n_in': sum(1 for c in b_in if c),
            'note': 'base ctor inits both 296B states; y0 = ground radius'}


def f1_single_tick(world, N):
    """Entry tick(N) vs direct [k(1), k(0)x(N-2)] and [k(1), k(0)x(N-1)]."""
    world.reset_kernel_ctx()
    caps, w = capture_kernel_entry(world)
    world.set_state((0, 3.0, 0))
    world.set_N(N)
    out_entry = world.tick()
    world.core.unwatch(w)
    kcalls = [(c[1], c[2]) for c in caps]
    snap_first = caps[0][3] if caps else None
    # direct candidates
    cands = {}
    for label, seq in [
        ('N-1_rule', [(1, 0)] + [(0, 0)] * (N - 2)),
        ('N_rule', [(1, 0)] + [(0, 0)] * (N - 1)),
    ]:
        if N >= 1 and len(seq) >= 1:
            world.reset_kernel_ctx()
            cands[label] = direct_kernel_seq(world, snap_first, seq)
    diffs = {k: sum(a != b for a, b in zip(v, out_entry))
             for k, v in cands.items()}
    best = min(diffs, key=diffs.get)
    return {'name': 'F1_single_tick', 'N': N, 'kernel_calls': kcalls,
            'diffs': diffs, 'pass': diffs[best] == 0, 'best_rule': best,
            'note': 'entry tick vs direct kernel sequences'}


def f2_trajectory(world, n_ticks=30, N=3):
    """30-tick trajectory: entry path vs direct N-1-rule sequence per tick.
    Uses the real flight state (phys=1 sub=6) so the run covers flight,
    landing and native bounces."""
    world.set_state((0, 3.0, 0), phys=1, sub=6)
    world.set_N(N)
    results = []
    cur = world.get_state(0x30)
    for t in range(n_ticks):
        world.reset_kernel_ctx()
        caps, w = capture_kernel_entry(world)
        world.core.uc.mem_write(world.ball + 0x30, cur)
        world.tick()
        world.core.unwatch(w)
        out_entry = world.get_state(0x158)
        snap_first = caps[0][3] if caps else cur
        # N-1 commit rule: [k(w4=1), k(w4=0) x (N-2)]
        seq = [(1, 0)] + [(0, 0)] * max(N - 2, 0)
        world.reset_kernel_ctx()
        out_direct = direct_kernel_seq(world, snap_first, seq) if N >= 1 else cur
        d = sum(a != b for a, b in zip(out_entry, out_direct))
        results.append(d)
        cur = out_entry  # feedback handshake
    return {'name': 'F2_trajectory', 'ticks': n_ticks, 'N': N,
            'per_tick_diffs': results, 'pass': all(d == 0 for d in results)}


def f3_snapshots(world, n_ticks=30, N=3):
    """Per-tick snapshot comparison: entry kernel-entry states (offset by one)
    vs direct per-call results — aligns with the N-1 commit rule."""
    world.set_state((0, 3.0, 0), phys=1, sub=6)
    world.set_N(N)
    maxd = 0
    detail = []
    cur = world.get_state(0x30)
    for t in range(n_ticks):
        world.reset_kernel_ctx()
        caps, w = capture_kernel_entry(world)
        world.core.uc.mem_write(world.ball + 0x30, cur)
        world.tick()
        world.core.unwatch(w)
        # entry kernel-entry snapshots: [initial, after k1, ..., after k(N-1)]
        snaps_entry = [c[3] for c in caps]
        # direct side: N-1 calls (commit rule), state after each call
        core = world.core
        st = core.alloc(STATE_SZ, snaps_entry[0], name='f3_state')
        snaps_direct = [snaps_entry[0]]
        for i in range(max(N - 1, 0)):
            world.reset_kernel_ctx()
            core.uc.mem_write(st, rd_state(core, st))
            r = core.call(A_KERNEL, w0=0, w1=1, x2=st, x3=world.params,
                          s0=1.0 / 27.0, w4=1 if i == 0 else 0, w5=0)
            if r['error']:
                raise RuntimeError(f'f3 direct call failed: {r}')
            snaps_direct.append(rd_state(core, st))
        # entry[i+1] (state entering call i+1) == direct[i+1] (after call i)
        for i in range(1, min(len(snaps_entry), len(snaps_direct))):
            d = sum(a != b for a, b in zip(snaps_entry[i], snaps_direct[i]))
            if d:
                detail.append((t, i, d))
            maxd = max(maxd, d)
        cur = world.get_state(0x158)
    return {'name': 'F3_snapshots', 'ticks': n_ticks, 'N': N,
            'max_byte_diff': maxd, 'first_diffs': detail[:8],
            'pass': maxd == 0}


def fb_bounce(world, n_ticks=270, N=3):
    """Native bounce through the full object path (feedback handshake).
    Flight state: phys=1 sub=6 — the native activation of the kernel bounce
    block (6ea0bd8: sub==6, phys!=0, y<=radius -> vy *= -0.8, y = radius)."""
    world.set_state((0, 3.0, 0), vel=(0, 0, 0), phys=1, sub=6)
    world.set_N(N)
    ys, vys = [], []
    for t in range(n_ticks):
        out = world.tick_feedback()
        pos = state_vec(out)
        vel = state_vec(out, 0x0C)
        ys.append(pos[1])
        vys.append(vel[1])
    # peak detection: local maxima above radius after first bounce
    peaks = []
    for i in range(1, len(ys) - 1):
        if ys[i] > ys[i - 1] and ys[i] > ys[i + 1] and ys[i] > RADIUS * 1.5:
            peaks.append(ys[i])
    rest = None
    if len(peaks) >= 2:
        rest = peaks[1] / peaks[0]
    return {'name': 'FB_bounce', 'peaks': peaks[:6],
            'restitution': rest, 'max_y': max(ys),
            'pass': len(peaks) >= 3 and 0.5 < (rest or 0) < 0.9,
            'note': 'native drop-bounce via object path; expected peaks '
                    '2.05/1.42/0.96/0.64, restitution ~0.68'}


def fc_commit_rule(world, Ns=(2, 3, 5, 8)):
    """tick(N) output == direct sequence of N-1 kernel calls."""
    out = {}
    for N in Ns:
        world.set_state((0, 3.0, 0))
        world.set_N(N)
        world.reset_kernel_ctx()
        caps, w = capture_kernel_entry(world)
        e = world.tick()
        world.core.unwatch(w)
        n_called = len(caps)
        # committed substeps: compare against direct seqs of length N-1 and N
        snap = caps[0][3]
        d_nm1 = d_n = None
        world.reset_kernel_ctx()
        s1 = direct_kernel_seq(world, snap, [(1, 0)] + [(0, 0)] * max(N - 2, 0))
        d_nm1 = sum(a != b for a, b in zip(s1, e))
        world.reset_kernel_ctx()
        s2 = direct_kernel_seq(world, snap, [(1, 0)] + [(0, 0)] * max(N - 1, 0))
        d_n = sum(a != b for a, b in zip(s2, e))
        out[N] = {'kernel_calls_per_tick': n_called,
                  'diff_vs_Nm1_seq': d_nm1, 'diff_vs_N_seq': d_n,
                  'rule': 'N-1' if d_nm1 == 0 and d_n != 0 else
                          ('N' if d_n == 0 and d_nm1 != 0 else 'ambiguous')}
    ok = all(v['rule'] in ('N-1', 'N') for v in out.values()) and \
        len({v['rule'] for v in out.values()}) == 1
    return {'name': 'FC_commit_rule', 'results': out, 'pass': bool(ok)}


def main():
    fast = '--fast' in sys.argv
    diag = '--diag' in sys.argv
    world = BallWorld(verbose=True)
    world.construct()
    print('[run] ball module constructed at', hex(world.ball))

    res = {}
    res['F0'] = f0_construction(world)
    print('[F0]', res['F0'])

    if diag:
        print('[diag] import calls:', dict(list(world.core.import_calls.items())[:40]))
        print('[diag] log tail:', world.core._log[-30:])
        return

    res['F1'] = f1_single_tick(world, N=3)
    print('[F1]', res['F1'])

    res['FC'] = fc_commit_rule(world)
    print('[FC]', res['FC'])

    if not fast:
        res['F2'] = f2_trajectory(world, n_ticks=30)
        print('[F2] per-tick diffs:', res['F2']['per_tick_diffs'][:10],
              '... pass =', res['F2']['pass'])

        res['F3'] = f3_snapshots(world, n_ticks=30)
        print('[F3]', res['F3'])

        res['FB'] = fb_bounce(world)
        print('[FB]', res['FB'])

    json.dump(res, open(OUT, 'w'), indent=1, default=float)
    print('JSON ->', OUT)
    all_pass = all(v.get('pass') for v in res.values())
    print('ALL PASS:', all_pass)


if __name__ == '__main__':
    main()
