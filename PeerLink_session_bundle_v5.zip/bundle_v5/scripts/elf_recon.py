#!/usr/bin/env python3
"""ELF reconnaissance of eFootball 11.0.1 libUE4.so (ARM64 Android).

Validates:
- ELF structure (segments, sections, dynamic deps, relocation profile)
- The 9 pinned function offsets from prior lab work (prologue sanity)
- PAC/BTI presence (matters for Unicorn emulation strategy)
- Symbol table availability (stripped or not)

Output: /home/z/my-project/apk_lab/analysis/elf_recon.json
"""
import json, os, struct, sys
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN

SO = '/home/z/my-project/apk_lab/libUE4.so'
OUT = '/home/z/my-project/apk_lab/analysis/elf_recon.json'
os.makedirs(os.path.dirname(OUT), exist_ok=True)

# Pinned offsets from the task spec (prior lab, SHA-256-matched binary)
PINNED = {
    'ball_state_ctor':      0x6d82418,  # constructs the two 296-byte physics-state buffers
    'ball_chain_top':       0x6ea1e90,  # BallPhysicsState -> ... entry
    'ball_chain_mid':       0x6ea20fc,
    'ball_kernel':          0x6ea0958,  # central ball update kernel
    'timestep_provider':    0x6813eb8,  # returns 27.0 -> dt = 1/27
    'player_replay_path_a': 0x6f4625c,  # live-state serialization path
    'player_replay_writer': 0x728d7e0,  # player replay-state writer
    'ball_replay_path_a':   0x6e94cec,  # live ball replay path
    'ball_replay_writer':   0x728d930,
}

PROLOGUE_MNEMONICS = {'stp', 'sub', 'pacibsp', 'bti', 'stp.nq'}  # first-insn candidates

f = open(SO, 'rb')
elf = ELFFile(f)

report = {'file': SO, 'size': os.path.getsize(SO), 'machine': elf.header['e_machine'],
          'type': elf.header['e_type'], 'entry': elf.header['e_entry']}

# ---- segments ----
loads = []
for seg in elf.iter_segments():
    t = seg['p_type']
    if t == 'PT_LOAD':
        fl = seg['p_flags']
        perms = ('r' if fl & 4 else '-') + ('w' if fl & 2 else '-') + ('x' if fl & 1 else '-')
        loads.append({'vaddr': seg['p_vaddr'], 'memsz': seg['p_memsz'], 'filesz': seg['p_filesz'],
                      'offset': seg['p_offset'], 'perms': perms})
report['pt_load'] = loads

# ---- sections of interest ----
secinfo = {}
for s in elf.iter_sections():
    n = s.name
    if n in ('.dynsym', '.dynstr', '.symtab', '.strtab', '.rodata', '.data.rel.ro', '.data', '.bss',
             '.text', '.plt', '.init_array', '.rela.dyn', '.rela.plt', '.got', '.got.plt'):
        secinfo[n] = {'addr': s['sh_addr'], 'size': s['sh_size']}
report['sections'] = secinfo

# ---- dynamic ----
dyn = {}
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_DYNAMIC':
        for tag in seg.iter_tags():
            k = tag.entry.d_tag
            if k in ('DT_NEEDED', 'DT_SONAME'):
                dyn.setdefault(k, []).append(tag.needed if k == 'DT_NEEDED' else tag.soname)
            elif k in ('DT_FLAGS', 'DT_FLAGS_1', 'DT_INIT', 'DT_FINI', 'DT_INIT_ARRAY',
                       'DT_INIT_ARRAYSZ', 'DT_PLTGOT', 'DT_STRSZ', 'DT_SYMTAB'):
                dyn[k] = tag.entry.d_val
report['dynamic'] = dyn

# ---- relocation profile (count by type, no full iteration) ----
relcount = {}
RELA_SZ = 24
for s in elf.iter_sections():
    from elftools.elf.relocation import RelocationSection
    if isinstance(s, RelocationSection):
        n = s.num_relocations() if s['sh_entsize'] else 0
        relcount[s.name] = {'entries': n, 'bytes': s['sh_size']}
report['relocations'] = relcount

# ---- symbol availability ----
dynsym = elf.get_section_by_name('.dynsym')
report['dynsym_count'] = dynsym.num_symbols() if dynsym else 0
symtab = elf.get_section_by_name('.symtab')
report['symtab_count'] = symtab.num_symbols() if symtab else 0
report['stripped'] = symtab is None

# ---- vaddr -> file offset ----
def v2o(v):
    for l in loads:
        if l['vaddr'] <= v < l['vaddr'] + l['filesz']:
            return v - l['vaddr'] + l['offset']
    return None

# ---- validate pinned offsets ----
md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)
md.detail = False
fdata = open(SO, 'rb').read()  # 160 MB into RAM once (host has enough)

def dis(v, n=16):
    o = v2o(v)
    if o is None:
        return None, ['<UNMAPPED>']
    code = fdata[o:o + n * 4]
    return o, list(md.disasm(code, v))

report['pinned'] = {}
prologue_ok = 0
for name, v in sorted(PINNED.items(), key=lambda kv: kv[1]):
    o, insns = dis(v, 12)
    entry = {'vaddr': hex(v), 'file_off': hex(o) if o is not None else None}
    if insns and insns != ['<UNMAPPED>']:
        entry['first_insns'] = [f"{i.mnemonic} {i.op_str}" for i in insns[:6]]
        entry['n_decoded'] = len(insns)
        first = insns[0].mnemonic if insns else ''
        entry['prologue_plausible'] = first in PROLOGUE_MNEMONICS or (insns and insns[0].mnemonic.startswith('pac'))
        if entry['prologue_plausible']:
            prologue_ok += 1
    else:
        entry['prologue_plausible'] = False
    # PAC/BTI scan in first 48 insns
    _, more = dis(v, 48)
    pacbti = set()
    for i in (more or []):
        m = i.mnemonic
        if m.startswith('paci') or m.startswith('auti') or m == 'bti' or m.startswith('retaa') or m.startswith('retab') or m.startswith('braa') or m.startswith('brab') or m.startswith('blda'):
            pacbti.add(m)
    entry['pac_bti_here'] = sorted(pacbti)
    report['pinned'][name] = entry

report['pinned_prologue_ok'] = prologue_ok
report['pinned_total'] = len(PINNED)

# ---- global PAC/BTI + section features from GNU notes ----
notes = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_NOTE' and hasattr(seg, 'iter_notes'):
        try:
            for note in seg.iter_notes():
                notes.append(str(note['n_name']) + '/' + str(note['n_type']))
        except Exception:
            pass
report['notes'] = notes[:20]

# ---- instruction sample of timestep provider (should compute/return 27.0) ----
_, ts = dis(PINNED['timestep_provider'], 24)
if ts and ts != ['<UNMAPPED>']:
    report['timestep_provider_insns'] = [f"{i.mnemonic} {i.op_str}" for i in ts]

json.dump(report, open(OUT, 'w'), indent=1)
print('=== ELF RECON ===')
print(f"file: {report['size']:,} bytes, type {report['type']}, entry {hex(report['entry'])}")
for l in loads:
    print(f"  LOAD {l['perms']} vaddr={hex(l['vaddr'])}-{hex(l['vaddr']+l['memsz'])} filesz={l['filesz']:,}")
print(f"dynsym: {report['dynsym_count']}  symtab: {report['symtab_count']}  stripped: {report['stripped']}")
print('DT_NEEDED:', dyn.get('DT_NEEDED'))
print('relocs:', {k: v['entries'] for k, v in relcount.items()})
print(f"pinned prologues OK: {prologue_ok}/{len(PINNED)}")
for name, e in report['pinned'].items():
    fi = e.get('first_insns', ['?'])[:2]
    print(f"  {name:22s} {e['vaddr']}  {'OK ' if e['prologue_plausible'] else '?? '} {fi}  pacbti={e['pac_bti_here']}")
print('notes:', report['notes'])
if report.get('timestep_provider_insns'):
    print('timestep provider (first 12):')
    for i in report['timestep_provider_insns'][:12]:
        print('   ', i)
print('JSON ->', OUT)
