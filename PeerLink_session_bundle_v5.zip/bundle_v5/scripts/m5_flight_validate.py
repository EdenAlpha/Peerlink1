#!/usr/bin/env python3
"""MILESTONE 5: full-flight validation through the REAL GAME PATH.

The lockstep proof at ball level: install the kick state (from .rep f48),
tick the module through the real per-frame path 0x6a059b0 (match -> mgr ->
driver_C -> module -> kernel), and compare against the .rep oracle records
frames 48..123 (the complete flight + goal + reset).

Captures:
- 0x6a6b604 recorder writes (the .rep 28-byte ball record writer)
- module published state (+0x158) and input state (+0x30)
- per-frame quantized comparison vs .rep slot-0 blocks

Params: airRegist = 0.399, mode 8 (M3-calibrated stand-ins for paramsB).
"""
import json
import os
import struct
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from uc_loader2 import EFootballCoreV2
from ball_object_run import BallWorld, rd_state, state_vec, A_TICK
from unicorn.arm64_const import *

OUT = '/home/z/my-project/apk_lab/analysis/m5_flight_validate.json'
REP = ('/home/z/my-project/apk_lab/cpk/dt270_out/common/match/'
       'tutorial_replay/tutorial_replay_shooting_02.rep')
HDR, REC = 44400, 10976
A_MGR_CTOR = 0x6a352c4
A_UPDATE_BALL_MOD = 0x6a059b0
A_RECORDER_WRITE = 0x6a6b604
OFF_BALL_MGR = 0x3C98

# M3-calibrated kick state (fit closed at quantization-noise level)
P0 = (38.5, 0.105, 0.0)
V0 = (24.76, 5.20, -4.70)
AIR = 0.399
F_FIRST, F_LAST = 48, 123          # .rep oracle frames
N_TICKS = F_LAST - F_FIRST          # 75


def rep_slot0(f):
    d = open(REP, 'rb').read()
    base = HDR + f * REC
    blk = d[base + 0x2D4:base + 0x2D4 + 0x1C]
    q = struct.unpack_from('<4f', blk, 0)
    x, y, z = struct.unpack_from('<hhh', blk, 0x10)
    return {'raw': blk, 'quat': q, 'pos': (x / 256, y / 256, z / 256),
            'slot': blk[0x16], 'pref': blk[0x17],
            'flags': struct.unpack_from('<H', blk, 0x18)[0]}


def main():
    oracle = {f: rep_slot0(f) for f in range(F_FIRST, F_LAST + 2)}
    print(f"[oracle] frames {F_FIRST}..{F_LAST+1}; f{F_FIRST} pos={oracle[F_FIRST]['pos']}"
          f" f{F_FIRST+1} pos={oracle[F_FIRST+1]['pos']} f{F_LAST+1} pos={oracle[F_LAST+1]['pos']}")

    world = BallWorld(verbose=True)
    world.construct()
    core = world.core
    world.set_N(3)

    # --- module A (M2 construction) in manager (M4 architecture) ---
    modA = world.ball
    mgr = core.alloc(0x200, b'\0' * 0x200, name='ball_mgr')
    r = core.call(A_MGR_CTOR, x0=mgr)
    assert not r['error'], r
    core.write_u64(mgr + 0x38, modA)
    modB = core.alloc(0x14B8, b'\0' * 0x14B8, name='ball_module_B')
    r = core.call(0x6e92768, x0=modB, w1=1)
    holderB = core.alloc(0x8000, b'\0' * 0x8000, name='holderB')
    core.write_u8(modB + 0x360, 1)
    core.write_u64(modB + 0x3A0, holderB)
    r = core.call(0x6e91da8, x0=modB, w1=1)
    assert not r['error'], r
    core.write_u64(mgr + 0x40, modB)

    # --- install kick state into module A ---
    world.set_state(P0, vel=V0, phys=1, sub=6)
    # quat from the f48 record
    q = oracle[F_FIRST]['quat']
    st = bytearray(rd_state(core, modA + 0x30))
    struct.pack_into('<4f', st, 0x98, *q)
    struct.pack_into('<i', st, 0x8C, 8)      # mode 8 (paramsB stand-in)
    core.uc.mem_write(modA + 0x30, bytes(st))
    # params: airRegist
    core.uc.mem_write(world.params, struct.pack('<f', AIR))

    # --- recorder watcher ---
    rec_calls = []

    def wcb(uc, _):
        x0 = uc.reg_read(UC_ARM64_REG_X0)
        w1 = uc.reg_read(UC_ARM64_REG_X1) & 0xFFFFFFFF
        x2 = uc.reg_read(UC_ARM64_REG_X2)
        src = core.safe_read(x2, 0x1C) if x2 else b''
        rec_calls.append({'x0': hex(x0), 'idx': w1, 'src': x2,
                          'bytes': src.hex()})

    wk = core.watch(A_RECORDER_WRITE, wcb, name='recmon')

    # --- tick through the game's own entry (A_TICK + one-shot gate) ---
    print(f"\n[tick] {N_TICKS} frames via A_TICK 0x6e938a0 (physics entry)")
    err = None
    try:
        for k in range(N_TICKS):
            world.tick()
    except RuntimeError as e:
        err = str(e)
        print(f'  FAULT: {e}')
    core.unwatch(wk)

    st_out = rd_state(core, modA + 0x158)
    pos_out = state_vec(st_out)
    print(f"[tick] done; faults={err is not None}; out pos={pos_out}")
    print(f"[rec] 0x6a6b604 calls: {len(rec_calls)}")
    for c in rec_calls[:6]:
        print(f"   x0={c['x0']} idx={c['idx']} x2={hex(c['src'])} bytes={c['bytes']}")

    # --- comparison: module published state per tick vs oracle ---
    # re-run with per-frame capture (reset state identically)
    world.set_state(P0, vel=V0, phys=1, sub=6)
    st = bytearray(rd_state(core, modA + 0x30))
    struct.pack_into('<4f', st, 0x98, *q)
    struct.pack_into('<i', st, 0x8C, 8)
    core.uc.mem_write(modA + 0x30, bytes(st))
    rec_calls2 = []
    wk = core.watch(A_RECORDER_WRITE, wcb, name='recmon2')

    frames = []
    for k in range(N_TICKS):
        before_in = state_vec(rd_state(core, modA + 0x30))
        before_out = state_vec(rd_state(core, modA + 0x158))
        n0 = len(rec_calls2)
        try:
            out = world.tick()
        except RuntimeError as e:
            print(f'  FAULT at {k}: {e}')
            break
        after_out = state_vec(rd_state(core, modA + 0x158))
        after_in = state_vec(rd_state(core, modA + 0x30))
        frames.append({
            'k': k,
            'pre_in': before_in, 'pre_out': before_out,
            'post_out': state_vec(out), 'post_in': after_in,
            'rec_writes': len(rec_calls2) - n0,
        })

    core.unwatch(wk)

    # quantize module positions and compare vs oracle frames 49..
    def q16(p):
        return [int(round(v * 256)) for v in p]

    diffs = []
    for i, fr in enumerate(frames):
        f_oracle = F_FIRST + 1 + i
        o = oracle.get(f_oracle)
        if o is None:
            break
        for label, p in (('post_out', fr['post_out']), ('post_in', fr['post_in'])):
            qp = q16(p)
            qo = [int(round(v * 256)) for v in o['pos']]
            d = sum(abs(a - b) for a, b in zip(qp, qo))
            if label == 'post_out':
                diffs.append({'frame': f_oracle, 'qdiff': d,
                              'pred': [round(v, 3) for v in p],
                              'oracle': o['pos']})

    n_bad = sum(1 for x in diffs if x['qdiff'] != 0)
    max_err = max(np.abs(np.array([x['pred'] for x in diffs]) -
                         np.array([x['oracle'] for x in diffs])).max(axis=0).max() if diffs else 0,
                  0)
    print(f"\n[compare] {len(diffs)} frames vs oracle; exact-i16 frames: "
          f"{len(diffs)-n_bad}; max pos err {max_err*100:.1f} cm")
    for x in diffs[:8]:
        print(f"  f{x['frame']}: qdiff={x['qdiff']} pred={x['pred']} oracle={x['oracle']}")
    print('  ...')
    for x in diffs[-4:]:
        print(f"  f{x['frame']}: qdiff={x['qdiff']} pred={x['pred']} oracle={x['oracle']}")

    res = {
        'params': {'P0': P0, 'V0': V0, 'airRegist': AIR, 'mode': 8, 'N': 3},
        'faults': err is None,
        'rec_calls_total': len(rec_calls),
        'rec_calls_sample': rec_calls[:12],
        'per_frame_rec_writes': [f['rec_writes'] for f in frames[:20]],
        'diffs': diffs,
        'n_frames': len(diffs),
        'n_exact_i16': len(diffs) - n_bad,
        'max_pos_err_m': float(max_err),
    }
    json.dump(res, open(OUT, 'w'), indent=1, default=float)
    print(f'JSON -> {OUT}')


if __name__ == '__main__':
    main()
