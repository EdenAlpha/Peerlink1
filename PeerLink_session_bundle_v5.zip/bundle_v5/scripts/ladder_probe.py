#!/usr/bin/env python3
"""Probe: what does the observer-published state carry in the ladder region
(+0x74..0x98, mode +0x8c) during a native flight? FB fell from 3 m at up to
7.7 m/s without hitting the ladder recursion -> the published state must have
non-zero fields there. Capture them tick by tick."""
import struct
import sys

sys.path.insert(0, '/home/z/my-project/scripts')
from ball_object_run import BallWorld, state_vec
from unicorn.arm64_const import *  # noqa: F401

DT = 1.0 / 27.0


def dump_region(b, base=0x70, end=0x98):
    out = []
    for off in range(base, end, 4):
        f = struct.unpack_from('<f', b, off)[0]
        i = struct.unpack_from('<i', b, off)[0]
        tag = ''
        if off == 0x8c:
            tag = ' <- ladder mode'
        out.append(f'  +{off:03x}: {i:12d}  {f:12.5f}{tag}')
    return '\n'.join(out)


def main():
    world = BallWorld(verbose=False)
    world.construct()
    world.set_N(3)
    world.set_state((0, 3.0, 0), vel=(0, 0, 0), phys=1, sub=6)
    print('initial (set_state, zeros):')
    print(dump_region(world.get_state(0x30)))
    for t in range(30):
        out = world.tick_feedback()
        pos = state_vec(out)
        vel = state_vec(out, 0x0C)
        import math
        speed = math.sqrt(sum(v * v for v in vel))
        if t in (0, 3, 7, 11, 15, 19, 25, 29) or speed > 3.0:
            print(f'\ntick {t}: y={pos[1]:.4f} speed={speed:.4f} '
                  f'phys={out[0x90]} sub={out[0x91]} idx={struct.unpack_from("<i", out, 0x94)[0]}')
            print(dump_region(out))


if __name__ == '__main__':
    main()
