#!/usr/bin/env python3
"""M5.1f: hunt the .trep sample parser via the 844 (0x34C) size immediate
and 1200 (0x4B0) count. cmp/subs/movz with imm12/imm16 == 844 or 1200.
"""
import numpy as np
import json

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'
data = open(SO, 'rb').read()

from elftools.elf.elffile import ELFFile
f = open(SO, 'rb')
elf = ELFFile(f)
loads = [(s['p_vaddr'], s['p_memsz'], s['p_filesz'], s['p_offset'])
         for s in elf.iter_segments() if s['p_type'] == 'PT_LOAD']
loads.sort()

entries = np.load(f'{AN}/fgraph2.npz', allow_pickle=True)['entries']
entries.sort()


def func_of(a):
    i = np.searchsorted(entries, a, 'right') - 1
    return int(entries[i]) if i >= 0 else 0


results = {844: [], 1200: [], 828: [], 16: []}
for va, mem, fsz, fo in loads:
    seg = data[fo:fo + fsz]
    if len(seg) < 0x100000:
        continue
    words = np.frombuffer(seg, dtype='<u4')
    pc_base = va
    # cmp/subs imm12: (w & 0xFF000000) == 0x71000000, imm12 = (w>>10)&0xFFF
    # also movz w, #imm16: (w & 0xFFE00000) == 0x52800000
    cmp_mask = (words & 0xFF000000) == 0x71000000
    cmp_imm = (words >> 10) & 0xFFF
    for target in (844, 828):
        m = cmp_mask & (cmp_imm == target)
        for wi in np.nonzero(m)[0]:
            w = int(words[wi])
            pc = pc_base + int(wi) * 4
            # only CMP-style (SUBS with rd=xzr -> bits 4-0 == 31)
            if (w & 0x1F) == 0x1F:
                results[target].append(pc)
    movz_mask = (words & 0xFFE00000) == 0x52800000
    movz_imm = (words >> 5) & 0xFFFF
    m = movz_mask & (movz_imm == 1200)
    for wi in np.nonzero(m)[0]:
        pc = pc_base + int(wi) * 4
        results[1200].append(pc)

for tgt, pcs in results.items():
    print(f'\n=== imm {tgt}: {len(pcs)} sites ===')
    # cluster by function
    fns = {}
    for pc in pcs:
        fns.setdefault(func_of(pc), []).append(pc)
    for fs in sorted(fns, key=lambda x: -len(fns[x]))[:25]:
        print(f'  func {fs:#x}: {len(fns[fs])} hits at {[hex(p) for p in fns[fs][:6]]}')

json.dump({str(k): [hex(p) for p in v] for k, v in results.items()},
          open(f'{AN}/trep_size_sites.json', 'w'), indent=1)
print('\nJSON -> trep_size_sites.json')
