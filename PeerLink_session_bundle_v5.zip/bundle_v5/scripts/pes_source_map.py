#!/usr/bin/env python3
"""Map the Konami PES source tree embedded in libUE4.so.

Every __FILE__ / log-path string of the form G:\\PES22HC\\... points back to the
translation unit it was compiled from. adrp+add xrefs to those string starts
attribute functions to source files -> reconstructs the gameplay module layout
and identifies the Process/Match/* per-frame processors.

Output: apk_lab/analysis/pes_source_map.json
"""
import json, os, re, sys
import numpy as np
from elftools.elf.elffile import ELFFile
from capstone import Cs, CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN

SO = '/home/z/my-project/apk_lab/libUE4.so'
AN = '/home/z/my-project/apk_lab/analysis'

f = open(SO, 'rb')
elf = ELFFile(f)
loads = []
for seg in elf.iter_segments():
    if seg['p_type'] == 'PT_LOAD':
        fl = seg['p_flags']
        loads.append(dict(vaddr=seg['p_vaddr'], memsz=seg['p_memsz'], filesz=seg['p_filesz'],
                          offset=seg['p_offset'], perms=('r' if fl & 4 else '-') + ('w' if fl & 2 else '-') + ('x' if fl & 1 else '-')))
TEXT_VA, TEXT_SZ = loads[1]['vaddr'], loads[1]['filesz']

def v2o(v):
    for l in loads:
        if l['vaddr'] <= v < l['vaddr'] + l['filesz']:
            return v - l['vaddr'] + l['offset']
    return None

def o2v(o):
    for l in loads:
        if l['offset'] <= o < l['offset'] + l['filesz']:
            return o - l['offset'] + l['vaddr']
    return None

fdata = open(SO, 'rb').read()

# ---- 1. collect ALL PES22HC path strings in read-only segments ----
hits = []
for l in loads:
    if 'w' in l['perms'] or 'x' in l['perms']:
        continue
    seg = fdata[l['offset']:l['offset'] + l['filesz']]
    for m in re.finditer(rb'G:\\PES22HC\\[^\x00]{1,220}\.(?:cpp|h|cs)', seg):
        va = o2v(l['offset'] + m.start())
        # string start: ensure preceding byte is NUL (else suffix of longer string)
        o = l['offset'] + m.start()
        if o > 0 and fdata[o - 1] != 0:
            continue  # will be captured by the longer string's own match
        hits.append((va, m.group(0).decode('utf-8', 'replace')))
print(f'PES22HC strings (true starts): {len(hits):,}')

# ---- 2. xref machinery ----
bl = np.load(f'{AN}/bl_map.npz')
all_entries = np.unique(bl['bl_target'])
entries_sorted = np.sort(all_entries)

ad = np.load(f'{AN}/adrp_map.npz')
ref_target, ref_site, ref_kind = ad['ref_target'], ad['ref_site'], ad['ref_kind']
aorder = np.argsort(ref_target)
rt, rs, rk = ref_target[aorder], ref_site[aorder], ref_kind[aorder]

def refs_to(target):
    i = np.searchsorted(rt, target, 'left')
    j = np.searchsorted(rt, target, 'right')
    return list(zip(rs[i:j].tolist(), rk[i:j].tolist()))

md = Cs(CS_ARCH_ARM64, CS_MODE_LITTLE_ENDIAN)

def func_start(site, back=0x20000):
    o = v2o(site)
    lo = max(loads[1]['offset'], o - back)
    code = fdata[lo:o + 4]
    va = lo - loads[1]['offset'] + TEXT_VA
    insns = list(md.disasm(code, va))
    best = None
    for i, ins in enumerate(insns[:-1]):
        m, ops = ins.mnemonic, ins.op_str
        pro = (m == 'stp' and 'x29' in ops and 'x30' in ops) or \
              (m == 'sub' and ops.startswith('sp, sp, #')) or (m == 'pacibsp') or \
              (m == 'stp' and ops.startswith('x28'))
        if pro:
            prev = insns[i - 1] if i > 0 else None
            if prev is None or prev.mnemonic in ('ret', 'nop', 'b', 'brk', 'br', 'blr') or prev.mnemonic.startswith('b.'):
                best = ins.address
    return best

def fsize(entry):
    i = np.searchsorted(entries_sorted, entry, 'right')
    nxt = entries_sorted[i] if i < len(entries_sorted) else TEXT_VA + TEXT_SZ
    return min(nxt - entry, 0x20000)

# ---- 3. attribute functions to source files ----
file_funcs = {}
for va, path in hits:
    rr = refs_to(va)
    for site, kind in rr:
        st = func_start(site)
        if st:
            file_funcs.setdefault(path, {}).setdefault(st, 0)
            file_funcs[path][st] += 1

# ---- 4. organize by directory ----
def dirkey(p):
    m = re.search(r'Source\\(Shared|Client|Server)?\\(.*)\\([^\\]+)$', p)
    tail = p.replace('G:\\PES22HC\\Dev-600Series\\', '')
    return tail.rsplit('\\', 1)[0]

dirs = {}
for path, funcs in file_funcs.items():
    d = dirkey(path)
    dirs.setdefault(d, []).append((path, funcs))

print(f'\nfiles with attributed functions: {len(file_funcs):,}   dirs: {len(dirs):,}')

# focus: gameplay-relevant directories
FOCUS_DIRS = ['Game\\Process', 'Game\\Match', 'Game\\Ball', 'Game\\Player', 'Game\\Team',
              'Game\\Common', 'Game\\Replay', 'Game\\Command', 'Game\\Controller']
summary = {}
for d in sorted(dirs):
    for fd in FOCUS_DIRS:
        if fd.lower() in d.lower():
            summary[d] = []
            for path, funcs in sorted(dirs[d], key=lambda x: x[0]):
                finfo = [{'func': hex(a), 'size': fsize(a), 'nrefs': n} for a, n in sorted(funcs.items())]
                summary[d].append({'file': path, 'n_funcs': len(funcs), 'funcs': finfo})
            total = sum(len(funcs) for _, funcs in dirs[d])
            print(f'  [{d}] {len(dirs[d])} files, {total} functions')

dirs_out = {}
for d, fs in dirs.items():
    dirs_out[d] = [{'file': p, 'funcs': [hex(a) for a in sorted(funcs)]} for p, funcs in fs]
json.dump({'n_strings': len(hits), 'dirs': dirs_out}, open(f'{AN}/pes_dirs.json', 'w'), indent=1)
json.dump(summary, open(f'{AN}/pes_focus.json', 'w'), indent=1)

print('\n=== Process dir detail (top by function count) ===')
for d in sorted(summary):
    for fe in sorted(summary[d], key=lambda x: -x['n_funcs'])[:12]:
        big = sorted(fe['funcs'], key=lambda x: -x['size'])[:4]
        big_s = ', '.join('%s(%s)' % (x['func'], format(x['size'], ',')) for x in big)
        name = fe['file'].rsplit('\\', 1)[-1]
        print('  %-50s nfuncs=%-3d biggest: %s' % (name, fe['n_funcs'], big_s))
