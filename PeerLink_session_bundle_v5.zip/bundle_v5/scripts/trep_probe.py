#!/usr/bin/env python3
"""Probe .trep command-sample structure (the per-frame input stream).

Goal: find how command records are laid out in each 844-byte sample and
whether they map onto the 110-command dispatcher (0x6a00e50, [cmd+8]=id).

Approach:
- dump first samples hex
- statistics per u16 lane across all 1200 samples (stability vs variance)
- look for small-int command-id lanes (0..0x6c)
- diff consecutive samples (commands are sparse per frame)
"""
import struct
import numpy as np

BASE = '/home/z/my-project/apk_lab/cpk/dt270_out/common/match/tutorial_replay'
N, S = 1200, 844

d = open(f'{BASE}/tutorial_replay_shooting_02.trep', 'rb').read()
print('header 12B:', d[:12].hex(' '))
samples = np.frombuffer(d[12:], dtype=np.uint8).reshape(N, S).copy()

# u16 lanes
u16 = samples.view('<u2') if samples.dtype == np.uint8 else None
u16 = samples.view(np.dtype('<u2')).reshape(N, S // 2)
print(f'u16 lanes: {u16.shape[1]}')

stable = (u16 == u16[0]).all(axis=0)
print(f'lanes constant across all frames: {stable.sum()}')
print('constant lane values (lane: val):', [(i, int(u16[0, i])) for i in np.nonzero(stable)[0][:40]])

# lanes that look like small ints (command ids / counts)
small = [(i, int(u16[:, i].min()), int(u16[:, i].max())) for i in range(u16.shape[1])
         if not stable[i] and u16[:, i].max() < 0x80]
print(f'\nnon-constant small-valued lanes (<0x80): {len(small)}')
for i, mn, mx in small[:60]:
    uniq, cnt = np.unique(u16[:, i], return_counts=True)
    top = list(zip(uniq.tolist(), cnt.tolist()))[:6]
    print(f'  lane {i:4d} (byte {2*i:4d}): min={mn:3d} max={mx:3d} top={top}')

# byte-level: first 3 samples hex dump (first 160 bytes each)
for s in range(3):
    print(f'\nsample {s}:')
    row = samples[s][:160]
    for off in range(0, 160, 32):
        print(f'  +{off:03x}: {row[off:off+32].hex(" ")}')

# frames where sample differs from previous (sparse commands?)
diff_mask = np.zeros(N, dtype=bool)
diff_mask[1:] = (samples[1:] != samples[:-1]).any(axis=1)
print(f'\nframes differing from previous: {diff_mask.sum()} / {N}')
nz = np.nonzero(diff_mask)[0]
print('first 40 changing frames:', nz[:40].tolist())
