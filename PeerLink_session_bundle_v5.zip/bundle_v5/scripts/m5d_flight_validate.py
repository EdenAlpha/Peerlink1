#!/usr/bin/env python3
"""M5d: flight validation, clean-airborne window (frames 49..80) through
the real continuous tick, with recorder-record mapping.

Also maps: of the 3 recorder writes per tick, which one carries the
.rep record position (the .rep slot-0 stream).
"""
import json
import os
import struct
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ball_object_run import BallWorld, rd_state, state_vec, STATE_SZ
from unicorn.arm64_const import *

OUT = '/home/z/my-project/apk_lab/analysis/m5d_flight_validate.json'
REP = ('/home/z/my-project/apk_lab/cpk/dt270_out/common/match/'
       'tutorial_replay/tutorial_replay_shooting_02.rep')
HDR, REC = 44400, 10976
A_CONT_TICK = 0x6e92ce8
A_RECORDER_WRITE = 0x6a6b604
F_FIRST, F_CLEAN_END = 48, 80          # install f48, compare 49..80


def rep_slot0(f):
    d = open(REP, 'rb').read()
    base = HDR + f * REC
    blk = d[base + 0x2D4:base + 0x2D4 + 0x1C]
    q = struct.unpack_from('<4f', blk, 0)
    x, y, z = struct.unpack_from('<hhh', blk, 0x10)
    return {'quat': q, 'pos': (x / 256, y / 256, z / 256), 'raw': blk}


def main():
    oracle = {f: rep_slot0(f) for f in range(F_FIRST, F_CLEAN_END + 2)}
    o48 = oracle[F_FIRST]
    p48 = o48['pos']
    p49 = oracle[F_FIRST + 1]['pos']
    v_imp = tuple((np.array(p49) - np.array(p48)) * 27.0)
    v0 = (v_imp[0], v_imp[1] + 9.80665 / 27.0, v_imp[2])

    world = BallWorld(verbose=True)
    world.construct()
    modA = world.ball
    core = world.core

    def install(V0, mode=8, air=0.399):
        s = bytearray(STATE_SZ)
        struct.pack_into('<3f', s, 0x000, *p48)
        struct.pack_into('<3f', s, 0x00C, *V0)
        s[0x90] = 1
        s[0x91] = 6
        struct.pack_into('<4f', s, 0x098, *o48['quat'])
        struct.pack_into('<i', s, 0x08C, mode)
        core.uc.mem_write(modA + 0x158, bytes(s))
        core.write_u64(modA + 0x2F8, 0)
        core.write_u32(modA + 0x8, 0)
        core.uc.mem_write(world.params + 8, struct.pack("<f", air))
        world.set_N(3)

    recs = []

    def wcb(uc, _):
        x2 = uc.reg_read(UC_ARM64_REG_X2)
        w1v = uc.reg_read(UC_ARM64_REG_X1) & 0xFFFFFFFF
        src = core.safe_read(x2, 0x1C) if x2 else b''
        recs.append((w1v, src))

    n = F_CLEAN_END - F_FIRST          # 32 frames
    install(v0)
    wk = core.watch(A_RECORDER_WRITE, wcb, name='rec')
    rows = []
    for k in range(n):
        r = core.call(A_CONT_TICK, x0=modA, s0=1.0, w1=0)
        assert not r['error'], r
        st = state_vec(rd_state(core, modA + 0x158))
        rows.append({'k': k, 'frame': F_FIRST + 1 + k, 'pred': st,
                     'oracle': oracle[F_FIRST + 1 + k]['pos']})
    core.unwatch(wk)

    errs = np.array([np.array(rw['pred']) - np.array(rw['oracle'])
                     for rw in rows])
    rms = float(np.sqrt((errs ** 2).sum(axis=1).mean()))
    maxe = float(np.abs(errs).max())
    nq = sum(1 for rw in rows
             if [int(round(v * 256)) for v in rw['pred']] ==
             [int(round(v * 256)) for v in rw['oracle']])
    print(f'[clean flight 49..{F_CLEAN_END}] n={n} rms={rms*100:.2f}cm '
          f'max={maxe*100:.1f}cm exact_i16={nq}/{n} recs={len(recs)}')
    for rw in rows[:6] + rows[-4:]:
        e = [round(v, 3) for v in np.array(rw['pred']) - np.array(rw['oracle'])]
        print(f"  f{rw['frame']}: pred={tuple(round(v,3) for v in rw['pred'])} "
              f"oracle={rw['oracle']} err={e}")

    # map recorder records: per tick, 3 writes; find which matches oracle
    per_tick = [recs[i:i + 3] for i in range(0, len(recs), 3)]
    print('\nrecorder records per tick (first 5 ticks):')
    match_counts = [0, 0, 0]
    for t, tickrecs in enumerate(per_tick[:40]):
        o = oracle.get(F_FIRST + 1 + t)
        if o is None:
            break
        line = []
        for j, (idx, src) in enumerate(tickrecs):
            pos = struct.unpack_from('<3f', src, 0)
            dq = sum(abs(a - b) for a, b in zip(pos, o['pos']))
            if dq < 0.01:
                match_counts[j] += 1
            line.append(f'idx{idx}:({pos[0]:.2f},{pos[1]:.2f},{pos[2]:.2f})')
        if t < 5:
            print(f'  tick {t}: ' + '  '.join(line) +
                  f'  oracle=({o["pos"][0]:.2f},{o["pos"][1]:.2f},{o["pos"][2]:.2f})')
    print(f'recorder-slot oracle matches over 32 ticks: {match_counts}')

    json.dump({'rows': rows, 'rms_m': rms, 'max_err_m': maxe,
               'exact_i16': nq, 'match_counts': match_counts,
               'v0': v0,
               'recs': [[i, s.hex()] for i, s in recs[:96]]},
              open(OUT, 'w'), indent=1, default=float)
    print(f'JSON -> {OUT}')


if __name__ == '__main__':
    main()
