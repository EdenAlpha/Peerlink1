#!/usr/bin/env python3
"""Mini-test v2: ranged UC_HOOK_CODE stub trampoline pattern for ARM64 imports.
- stub pages contain self-branch (never executed)
- ranged code hook emulates the 'import', rewrites PC=LR
- main run stops at RET trap via emu_start(begin, until)
"""
from unicorn import *
from unicorn.arm64_const import *
import struct, time

uc = Uc(UC_ARCH_ARM64, UC_MODE_LITTLE_ENDIAN)
BASE = 0x10000000000
STUB = BASE + 0x1000000
RET = 0x30000000000

uc.mem_map(BASE, 0x1000, UC_PROT_ALL)      # code
uc.mem_map(STUB, 0x2000, UC_PROT_ALL)      # stubs
uc.mem_map(RET, 0x1000, UC_PROT_ALL)       # ret trap page

# main code: [0] bl stubA ; [4] bl stubB ; [8] nop
BL_A = 0x94000000 | ((STUB - (BASE + 0)) >> 2) & 0x3FFFFFF
BL_B = 0x94000000 | ((STUB + 0x1000 - (BASE + 4)) >> 2) & 0x3FFFFFF
code = struct.pack('<III', BL_A, BL_B, 0xD503201F)
uc.mem_write(BASE, code)
# stubs: self-branch
uc.mem_write(STUB, struct.pack('<I', 0x14000000))
uc.mem_write(STUB + 0x1000, struct.pack('<I', 0x14000000))

calls = []
def stub_hook(uc, addr, size, ud):
    idx = (addr - STUB) // 0x1000
    calls.append(idx)
    lr = uc.reg_read(UC_ARM64_REG_LR)
    # 'import': set x0 = 0x5550 + idx
    uc.reg_write(UC_ARM64_REG_X0, 0x5550 + idx)
    uc.reg_write(UC_ARM64_REG_PC, lr)

uc.hook_add(UC_HOOK_CODE, stub_hook, begin=STUB, end=STUB + 0x2000)

uc.reg_write(UC_ARM64_REG_X0, 0)
uc.reg_write(UC_ARM64_REG_LR, RET)
t0 = time.time()
try:
    uc.emu_start(BASE, RET, timeout=5_000_000, count=100000)
except UcError as e:
    print('emu err:', e)
dt = time.time() - t0
print(f'elapsed: {dt*1000:.1f} ms; calls: {calls}; final x0: {uc.reg_read(UC_ARM64_REG_X0):#x}; '
      f'PC: {uc.reg_read(UC_ARM64_REG_PC):#x}')
print("calls:", calls); assert calls == [0, 1], 'stub call order wrong'
assert uc.reg_read(UC_ARM64_REG_X0) == 0x5551
print('VERDICT: ranged-hook trampoline works, PC rewrite + ret trap OK')

# FPCR / TPIDR
try:
    uc.reg_write(UC_ARM64_REG_FPCR, 0)
    uc.reg_write(UC_ARM64_REG_FPSR, 0)
    uc.reg_write(UC_ARM64_REG_TPIDR_EL0, 0x20000000000)
    _ = uc.reg_read(UC_ARM64_REG_TPIDR_EL0)
    print('FPCR/FPSR/TPIDR_EL0: OK')
except Exception as e:
    print('reg fail:', e)
