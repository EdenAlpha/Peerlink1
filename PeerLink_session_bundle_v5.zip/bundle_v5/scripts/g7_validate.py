#!/usr/bin/env python3
"""G7 v3: windowed native-trajectory validation of the ORIGINAL ball kernel.

Method (honest):
- windows: y-parabola R^2 >= 0.995, length >= 12 (low-drag ballistic phases)
- v0 from first-two-frame finite differences (frames 1-2 match by construction
  -> scoring starts at frame 3)
- kernel stepped at native dt = 1/27
- report: frames-within-1LSB (from frame 3), first divergence frame, per-axis RMS
- try dt = 1/27 and 1/28.7 (record-clock candidates) and take the better one

Output: apk_lab/analysis/g7_validation.json
"""
import json, struct, sys, glob, os
import numpy as np
sys.path.insert(0, '/home/z/my-project/scripts')
from replay_parse import parse_rep, active_ball
from uc_loader import EFootballCore
from ball_poc import build_params, build_state, KERN

AN = '/home/z/my-project/apk_lab/analysis'
REPS = sorted(glob.glob('/home/z/my-project/apk_lab/cpk/dt270_out/common/match/tutorial_replay/*.rep'))
LSB = 1 / 256

tracks = {}
for p in REPS:
    r = parse_rep(p)
    tracks[os.path.basename(p)] = np.array([active_ball(rec)['pos'] for rec in r['records']])

def windows(bp, min_h=0.3, min_len=12):
    ok = bp[:, 1] >= min_h
    out, i, n = [], 0, len(ok)
    while i < n:
        if ok[i]:
            j = i
            while j + 1 < n and ok[j + 1]:
                j += 1
            if j - i + 1 >= min_len:
                y = bp[i:j+1, 1]
                t = np.arange(len(y)) / 27.0
                A = np.stack([np.ones_like(t), t, -0.5*t**2], axis=1)
                c, *_ = np.linalg.lstsq(A, y, rcond=None)
                pred = A @ c
                ss = ((y - y.mean())**2).sum()
                r2 = 1 - ((y - pred)**2).sum() / ss if ss > 0 else 1.0
                if r2 >= 0.995:
                    out.append((i, j + 1, r2))
            i = j + 1
        else:
            i += 1
    return out

core = EFootballCore(verbose=False)
core.fabricate_global(0xa465d88, size=0x40000)
params = build_params(core)

def kernel_run(pos0, v0, dt, steps):
    state = build_state(core, tuple(pos0), tuple(v0), (0, 0, 0), 0, 0)
    out = []
    for i in range(steps):
        r = core.call(KERN, w0=0, w1=1, x2=state, x3=params, s0=dt,
                      w4=1 if i == 0 else 0, w5=0)
        if r['error']:
            return None
        out.append(struct.unpack_from('<3f', bytes(core.uc.mem_read(state, 296)), 0))
    return np.array(out)

results = []
for name, bp in tracks.items():
    for (a, b, r2) in windows(bp):
        seg = bp[a:b]
        n = len(seg)
        for dt_label, dt in (('27', 1/27), ('28.7', 1/28.7)):
            v0 = (seg[1] - seg[0]) / dt
            sim = kernel_run(seg[0], v0, dt, n - 1)
            if sim is None:
                continue
            ref, pred = seg[1:], sim
            res = pred - ref
            err = np.abs(res).max(axis=1)
            within = int((err[2:] <= 1.0 * LSB).sum())   # from frame 3 (idx 2)
            first_div = next((k for k in range(2, len(err)) if err[k] > 1.0 * LSB), len(err))
            results.append({'file': name, 'a': a, 'b': b, 'r2': float(r2),
                            'dt': dt_label, 'n': n, 'within_1lsb_from_f3': within,
                            'first_div_frame_idx': int(first_div),
                            'rms': np.sqrt((res**2).mean(axis=0)).tolist()})

results.sort(key=lambda r: -r['within_1lsb_from_f3'])
print(f'{"file":<45}{"dt":>5}{"n":>4}{"<=1LSB":>8}{"1stdiv":>7}   rms')
for r in results[:18]:
    print(f'{r["file"]:<45}{r["dt"]:>5}{r["n"]:>4}{r["within_1lsb_from_f3"]:>8}'
          f'{r["first_div_frame_idx"]:>7}   [{r["rms"][0]:.3f},{r["rms"][1]:.3f},{r["rms"][2]:.3f}]')

best = results[0]
print(f'\nbest: {best}')
seg = tracks[best['file']][best['a']:best['b']]
dt = 1/27 if best['dt'] == '27' else 1/28.7
v0 = (seg[1] - seg[0]) / dt
sim = kernel_run(seg[0], v0, dt, best['n'] - 1)
res = sim - seg[1:]
print('frame-by-frame (best window):')
for i in range(min(len(res), 24)):
    e = np.linalg.norm(res[i])
    print(f'  f{i+1:3d}: err=({res[i][0]:+.4f},{res[i][1]:+.4f},{res[i][2]:+.4f}) |err|={e:.4f} m = {e/LSB:6.1f} LSB')

json.dump({'results': results, 'best': best}, open(f'{AN}/g7_validation.json', 'w'), indent=1)
print('JSON ->', f'{AN}/g7_validation.json')
