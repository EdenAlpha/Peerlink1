#!/usr/bin/env python3
"""M5.2: correlate .trep payload lanes with the .rep ball trajectory.

If a .trep float lane matches the .rep ball position per frame, the .trep
carries the ball state too (kinematic feed). Then map the full layout:
players block, ball, controller bits.
"""
import struct
import numpy as np

BASE = '/home/z/my-project/apk_lab/cpk/dt270_out/common/match'

# --- .rep parse (from replay_parse.py semantics: per-substep ball records) ---
d = open(f'{BASE}/tutorial_replay/tutorial_replay_shooting_02.rep', 'rb').read()
print(f'.rep size: {len(d)}')
print('.rep hdr 32B:', d[:32].hex(' '))

# known from prior sessions: records are 12 bytes; find the track by
# matching the M3 flight (frames 49..66, x 5..24 m at ~25 m/s)
# try straightforward: 12B records after some header
for hdr_sz in (0, 8, 12, 16, 32, 64):
    if (len(d) - hdr_sz) % 12 == 0:
        n = (len(d) - hdr_sz) // 12
        if 500 < n < 1300:
            print(f'  hdr {hdr_sz}: {n} records of 12B')
            recs = np.frombuffer(d[hdr_sz:hdr_sz + n * 12], dtype=np.uint8).reshape(n, 12)
            # interpret as 3 x i16 + 3 x u16? or 3 x u16 + ... try 3x i16 with 1/256 scale
            q = recs[:, :6].view('<i2').reshape(n, 3)
            pos = q.astype(np.float64) / 256.0
            print(f'    i16/256 x-range: {pos[:,0].min():.2f}..{pos[:,0].max():.2f}',
                  f'y {pos[:,1].min():.2f}..{pos[:,1].max():.2f}',
                  f'z {pos[:,2].min():.2f}..{pos[:,2].max():.2f}')

# --- .trep lanes ---
t = open(f'{BASE}/tutorial_replay/tutorial_replay_shooting_02.trep', 'rb').read()
samples = np.frombuffer(t[12:], dtype=np.uint8).reshape(1200, 844).copy()
pay_f = samples[:, 16:].view('<f4').reshape(1200, 207)

# candidate ball lanes: varying continuously
print('\n.trep varying f-lanes (continuous, >50 uniq):')
for i in range(207):
    lane = pay_f[:, i]
    u = np.unique(lane)
    if 50 < len(u) < 1300:
        nz = lane[lane != 0]
        print(f'  f-lane {i:3d} (byte {16+4*i:4d}): {len(u):4d} uniq, '
              f'range [{lane.min():10.4f}, {lane.max():10.4f}], '
              f'first40: {np.round(lane[:40], 2).tolist()[:40]}')
