#!/usr/bin/env python3
"""M5b: flight validation through the REAL .rep-stream generator.

0x6e92ce8(module, dt) -> 0x6ea233c -> ONE pure w4=0 substep with the
recorder observers -> this IS the per-frame .rep record stream.

Install kick state (from .rep f48), tick 75 frames, compare vs .rep
frames 49..123 at i16/256 quantization.
"""
import json
import os
import struct
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ball_object_run import BallWorld, rd_state, state_vec
from unicorn.arm64_const import *

OUT = '/home/z/my-project/apk_lab/analysis/m5b_flight_validate.json'
REP = ('/home/z/my-project/apk_lab/cpk/dt270_out/common/match/'
       'tutorial_replay/tutorial_replay_shooting_02.rep')
HDR, REC = 44400, 10976
A_CONT_TICK = 0x6e92ce8
A_RECORDER_WRITE = 0x6a6b604
DT = 1.0 / 27.0
F_FIRST, F_LAST = 48, 123


def rep_slot0(f):
    d = open(REP, 'rb').read()
    base = HDR + f * REC
    blk = d[base + 0x2D4:base + 0x2D4 + 0x1C]
    q = struct.unpack_from('<4f', blk, 0)
    x, y, z = struct.unpack_from('<hhh', blk, 0x10)
    return {'quat': q, 'pos': (x / 256, y / 256, z / 256), 'raw': blk}


def run(world, modA, P0, V0, quat, mode, air, n_ticks, w1=0):
    core = world.core
    world.set_N(3)
    world.set_state(P0, vel=V0, phys=1, sub=6)
    st = bytearray(rd_state(core, modA + 0x30))
    struct.pack_into('<4f', st, 0x98, *quat)
    struct.pack_into('<i', st, 0x8C, mode)
    core.uc.mem_write(modA + 0x30, bytes(st))
    core.uc.mem_write(world.params, struct.pack('<f', air))

    recs = []

    def wcb(uc, _):
        x2 = uc.reg_read(UC_ARM64_REG_X2)
        w1v = uc.reg_read(UC_ARM64_REG_X1) & 0xFFFFFFFF
        src = core.safe_read(x2, 0x1C) if x2 else b''
        recs.append((w1v, src))

    wk = core.watch(A_RECORDER_WRITE, wcb, name='rec')
    positions = []
    fault = None
    for k in range(n_ticks):
        r = core.call(A_CONT_TICK, x0=modA, s0=DT, w1=w1)
        if r['error']:
            fault = (k, r['error'])
            break
        positions.append(state_vec(rd_state(core, modA + 0x30)))
    core.unwatch(wk)
    return positions, recs, fault


def main():
    oracle = {f: rep_slot0(f) for f in range(F_FIRST, F_LAST + 2)}
    o48 = oracle[F_FIRST]

    world = BallWorld(verbose=True)
    world.construct()
    modA = world.ball
    core = world.core

    # state at f48: pos from record; velocity implied by records 48->49
    p48 = o48['pos']
    p49 = oracle[F_FIRST + 1]['pos']
    v_imp = tuple((np.array(p49) - np.array(p48)) / DT)
    # semi-implicit: implied = v + g*dt (post-advance) -> v0 = implied - g*dt
    v0 = (v_imp[0], v_imp[1] + 9.80665 * DT, v_imp[2])

    variants = []
    # variant sweep: w1 flag, mode, air, v0 (implied vs M3-fit)
    for name, V0, mode, air, w1 in [
        ('implied_v0_mode8_air0.399', v0, 8, 0.399, 0),
        ('implied_v0_mode8_air1.0', v0, 8, 1.0, 0),
        ('m3fit_v0_mode8_air0.399', (24.76, 5.20, -4.70), 8, 0.399, 0),
        ('implied_v0_mode0_air0.399', v0, 0, 0.399, 0),
    ]:
        if mode == 0:
            # mode 0 = ladder active: thresholds zeroed -> infinite recursion
            # risk; install nonzero thresholds to be safe
            pass
        positions, recs, fault = run(world, modA, p48, V0, o48['quat'],
                                     mode, air, F_LAST - F_FIRST, w1=w1)
        # compare positions vs oracle 49..123
        n = min(len(positions), F_LAST - F_FIRST)
        errs = []
        for i in range(n):
            o = oracle[F_FIRST + 1 + i]['pos']
            errs.append(tuple(np.array(positions[i]) - np.array(o)))
        errs = np.array(errs)
        rms = float(np.sqrt((errs ** 2).sum(axis=1).mean()))
        maxe = float(np.abs(errs).max()) if len(errs) else 0
        # quantized exactness
        nq = 0
        for i in range(n):
            qp = [int(round(v * 256)) for v in positions[i]]
            qo = [int(round(v * 256)) for v in oracle[F_FIRST + 1 + i]['pos']]
            if qp == qo:
                nq += 1
        v = {'name': name, 'fault': fault, 'n': n, 'rms_m': rms,
             'max_err_m': maxe, 'exact_i16_frames': nq,
             'rec_calls': len(recs),
             'first_pred': positions[0] if positions else None,
             'first_oracle': oracle[F_FIRST + 1]['pos'],
             'last_pred': positions[-1] if positions else None,
             'last_oracle': oracle[F_LAST]['pos']}
        variants.append(v)
        print(f'[{name}] fault={fault} n={n} rms={rms*100:.2f}cm '
              f'max={maxe*100:.1f}cm exact16={nq}/{n} recs={len(recs)}')
        if positions:
            print(f'   first: pred={tuple(round(x,3) for x in positions[0])} '
                  f'oracle={oracle[F_FIRST+1]["pos"]}')
            print(f'   last:  pred={tuple(round(x,3) for x in positions[-1])} '
                  f'oracle={oracle[F_LAST]["pos"]}')

    json.dump({'variants': variants, 'v0_implied': v0,
               'p48': p48, 'quat48': o48['quat']},
              open(OUT, 'w'), indent=1, default=float)
    print(f'JSON -> {OUT}')


if __name__ == '__main__':
    main()
